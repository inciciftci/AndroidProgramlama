package com.example.hafta5;

import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button btnSelectCity;
    private ScrollView cityScrollView;
    private ImageView slideshowImageView;
    private ImageView imageView1, imageView2, imageView3;
    private TextView textView1, textView2, textView3;
    private ConstraintLayout mainLayout;

    private int[] allImages = {
            R.drawable.antalyam, R.drawable.antalyaselale, R.drawable.antalyakaleici,
            R.drawable.istanbulgalata, R.drawable.istanbulortakoy, R.drawable.istanbulkizkulesi,
            R.drawable.maras, R.drawable.ceyhan, R.drawable.marassu
    };

    private Handler slideHandler = new Handler();
    private Random random = new Random();

    private Runnable slideRunnable = new Runnable() {
        @Override
        public void run() {
            int randomIndex = random.nextInt(allImages.length);
            slideshowImageView.setImageResource(allImages[randomIndex]);
            slideHandler.postDelayed(this, 2000); // 1.5x hız (3000ms / 1.5 = 2000ms)
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        mainLayout = findViewById(R.id.main);
        ViewCompat.setOnApplyWindowInsetsListener(mainLayout, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnSelectCity = findViewById(R.id.btnSelectCity);
        cityScrollView = findViewById(R.id.cityScrollView);
        slideshowImageView = findViewById(R.id.slideshowImageView);
        
        imageView1 = findViewById(R.id.imageView1);
        imageView2 = findViewById(R.id.imageView2);
        imageView3 = findViewById(R.id.imageView3);
        
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 = findViewById(R.id.textView3);

        btnSelectCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCityMenu(v);
            }
        });

        // Başlangıçta ana sayfa düzenini ayarla
        goHome();
    }

    private void showCityMenu(View v) {
        PopupMenu popupMenu = new PopupMenu(this, v);
        popupMenu.getMenu().add("Antalya");
        popupMenu.getMenu().add("İstanbul");
        popupMenu.getMenu().add("Kahramanmaraş");
        popupMenu.getMenu().add("Ana Sayfaya Dön");

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                String selected = item.getTitle().toString();
                if (selected.equals("Ana Sayfaya Dön")) {
                    goHome();
                } else {
                    displayCityPhotos(selected);
                }
                return true;
            }
        });
        popupMenu.show();
    }

    private void goHome() {
        cityScrollView.setVisibility(View.GONE);
        slideshowImageView.setVisibility(View.VISIBLE);
        btnSelectCity.setText("Şehir Seçin");

        // Butonu MERKEZE al
        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(mainLayout);
        constraintSet.connect(R.id.btnSelectCity, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP, 0);
        constraintSet.connect(R.id.btnSelectCity, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM, 0);
        constraintSet.applyTo(mainLayout);

        // Slayt devam etsin (veya baştan başlasın)
        slideHandler.removeCallbacks(slideRunnable);
        slideHandler.post(slideRunnable);
    }

    private void displayCityPhotos(String city) {
        slideshowImageView.setVisibility(View.GONE);
        cityScrollView.setVisibility(View.VISIBLE);
        btnSelectCity.setText(city);
        slideHandler.removeCallbacks(slideRunnable);

        // Butonu ÜSTE al (ilk halindeki gibi)
        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(mainLayout);
        constraintSet.clear(R.id.btnSelectCity, ConstraintSet.BOTTOM);
        constraintSet.connect(R.id.btnSelectCity, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP, 32);
        
        // ScrollView'ı butonun altına bağla
        constraintSet.connect(R.id.cityScrollView, ConstraintSet.TOP, R.id.btnSelectCity, ConstraintSet.BOTTOM, 16);
        
        constraintSet.applyTo(mainLayout);

        if (city.equals("Antalya")) {
            imageView1.setImageResource(R.drawable.antalyam);
            textView1.setText("Antalya - Düden Şelalesi");
            imageView2.setImageResource(R.drawable.antalyaselale);
            textView2.setText("Antalya - Kurşunlu Şelalesi");
            imageView3.setImageResource(R.drawable.antalyakaleici);
            textView3.setText("Antalya - Kaleiçi");
        } else if (city.equals("İstanbul")) {
            imageView1.setImageResource(R.drawable.istanbulgalata);
            textView1.setText("İstanbul - Galata Kulesi");
            imageView2.setImageResource(R.drawable.istanbulortakoy);
            textView2.setText("İstanbul - Ortaköy Camii");
            imageView3.setImageResource(R.drawable.istanbulkizkulesi);
            textView3.setText("İstanbul - Kız Kulesi");
        } else if (city.equals("Kahramanmaraş")) {
            imageView1.setImageResource(R.drawable.maras);
            textView1.setText("Kahramanmaraş - Tarihi Kale");
            imageView2.setImageResource(R.drawable.ceyhan);
            textView2.setText("Kahramanmaraş - Ceyhan Köprüsü");
            imageView3.setImageResource(R.drawable.marassu);
            textView3.setText("Kahramanmaraş - Yeşilgöz");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        slideHandler.removeCallbacks(slideRunnable);
    }
}