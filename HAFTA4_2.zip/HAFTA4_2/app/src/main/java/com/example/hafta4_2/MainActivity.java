package com.example.hafta4_2;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        final TextView textViewTitle = findViewById(R.id.textViewTitle);
        final ListView listViewCities = findViewById(R.id.listViewCities);

        final String[] cities = {"İstanbul", "Ankara", "İzmir", "Bursa", "Antalya", "Adana", "Konya"};

        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                cities
        );

        listViewCities.setAdapter(cityAdapter);

        listViewCities.setOnItemClickListener((parent, view, position, id) -> {
            String selectedCity = cities[position];
            String message = getString(R.string.city_selected_message, selectedCity);
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            textViewTitle.setText(selectedCity);
        });
    }
}