package com.example.bebiksoundsapp.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.bebiksoundsapp.data.model.SleepSession;

import java.util.List;

@Dao
public interface SleepSessionDao {

    @Insert
    void insert(SleepSession session);

    @Query("SELECT * FROM sleep_sessions ORDER BY date DESC, time DESC")
    List<SleepSession> getAllSessions();

    @Query("SELECT * FROM sleep_sessions WHERE babySlept = 1 ORDER BY minutesToSleep ASC")
    List<SleepSession> getSuccessfulSessions();

    @Query("SELECT * FROM sleep_sessions WHERE date >= :startDate ORDER BY date DESC")
    List<SleepSession> getSessionsSince(String startDate);

    @Query("SELECT COUNT(*) FROM sleep_sessions")
    int getSessionCount();

    @Query("DELETE FROM sleep_sessions")
    void deleteAll();
}
