package com.example.bebiksoundsapp.model

import androidx.compose.ui.graphics.Color
import com.example.bebiksoundsapp.ui.CategoryType
import com.example.bebiksoundsapp.ui.SoundItem

data class SoundCategory(
    val id: Int,
    val name: String,
    val emoji: String,
    val iconBackground: Color,
    val type: CategoryType = CategoryType.SOUND_LIST,
    val items: List<SoundItem> = emptyList()
)

val soundCategories = listOf(
    SoundCategory(1, "Ninniler", "🎵", Color(0xFF2A1020), items = listOf(SoundItem(101, "Fış Fış Kayıkçı", 0))),
    SoundCategory(2, "Klasik Müzik", "🎻", Color(0xFF28102A)),
    SoundCategory(3, "Beyaz Gürültü", "🌫", Color(0xFF10182A)),
    SoundCategory(4, "Doğa", "🍃", Color(0xFF102218)),
    SoundCategory(5, "Favoriler", "⭐", Color(0xFF1A1020), type = CategoryType.FAVORITES),
    SoundCategory(6, "Uyku Teknikleri", "💤", Color(0xFF101828), type = CategoryType.SLEEP_TIPS)
)
