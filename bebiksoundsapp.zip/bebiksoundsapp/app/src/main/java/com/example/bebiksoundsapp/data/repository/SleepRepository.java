package com.example.bebiksoundsapp.data.repository;

import android.app.Application;

import com.example.bebiksoundsapp.data.AppDatabase;
import com.example.bebiksoundsapp.data.dao.SleepSessionDao;
import com.example.bebiksoundsapp.data.model.SleepSession;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SleepRepository {

    private final SleepSessionDao dao;
    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    public SleepRepository(Application application) {
        AppDatabase db = AppDatabase
                .getInstance(application);
        dao = db.sleepSessionDao();
    }

    // Oturum kaydet (arka planda)
    public void insertSession(
            SleepSession session) {
        executor.execute(() ->
                dao.insert(session));
    }

    // Tum oturumlari getir
    public List<SleepSession> getAllSessions() {
        try {
            return executor.submit(
                    dao::getAllSessions).get();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    // Basarili oturumlari getir
    public List<SleepSession>
            getSuccessfulSessions() {
        try {
            return executor.submit(
                    dao::getSuccessfulSessions).get();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    // Son N gunun oturumlari
    public List<SleepSession>
            getRecentSessions(int days) {
        try {
            LocalDate startDate =
                    LocalDate.now().minusDays(days);
            String startDateStr =
                    startDate.toString();
            return executor.submit(() ->
                    dao.getSessionsSince(
                            startDateStr)).get();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public int getSessionCount() {
        try {
            return executor.submit(
                    dao::getSessionCount).get();
        } catch (Exception e) {
            return 0;
        }
    }
}
