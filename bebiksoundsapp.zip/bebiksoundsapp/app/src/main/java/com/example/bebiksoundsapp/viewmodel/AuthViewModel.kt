package com.example.bebiksoundsapp.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.bebiksoundsapp.data.model.UserProfile
import com.example.bebiksoundsapp.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(application: Application)
    : AndroidViewModel(application) {

    private val authRepository = AuthRepository()

    val isLoading = MutableStateFlow(false)
    val errorMessage = MutableStateFlow<String?>(null)
    val isLoggedIn = MutableStateFlow(
        authRepository.isLoggedIn)
    val currentProfile =
        MutableStateFlow<UserProfile?>(null)

    init {
        validateSession()
    }

    fun register(
        email: String,
        password: String,
        confirmPassword: String,
        displayName: String,
        username: String,
        photoUri: Uri?,
        kvkkAccepted: Boolean,
        termsAccepted: Boolean
    ) {
        if (!kvkkAccepted || !termsAccepted) {
            errorMessage.value =
                "Devam etmek için tüm " +
                    "koşulları onaylamalısınız"
            return
        }
        if (displayName.isBlank()) {
            errorMessage.value =
                "İsim boş bırakılamaz"
            return
        }
        if (username.length < 3) {
            errorMessage.value =
                "Kullanıcı adı en az " +
                    "3 karakter olmalı"
            return
        }
        if (!username.matches(
                Regex("^[a-zA-Z0-9_.]+$"))
        ) {
            errorMessage.value =
                "Kullanıcı adı sadece harf, " +
                    "rakam, _ ve . içerebilir"
            return
        }
        if (!email.contains("@")) {
            errorMessage.value =
                "Geçerli bir e-posta girin"
            return
        }
        if (password.length < 6) {
            errorMessage.value =
                "Şifre en az 6 karakter olmalı"
            return
        }
        if (password != confirmPassword) {
            errorMessage.value =
                "Şifreler eşleşmiyor"
            return
        }

        viewModelScope.launch {
            isLoading.value = true
            errorMessage.value = null

            val result = authRepository.register(
                email = email.trim(),
                password = password,
                displayName = displayName.trim(),
                username = username
                    .trim().lowercase(),
                photoUri = photoUri,
                context = getApplication()
            )

            result.fold(
                onSuccess = { profile ->
                    currentProfile.value = profile
                    isLoggedIn.value = true
                },
                onFailure = { e ->
                    errorMessage.value = e.message
                }
            )
            isLoading.value = false
        }
    }

    fun login(
        emailOrUsername: String,
        password: String
    ) {
        if (emailOrUsername.isBlank()) {
            errorMessage.value =
                "E-posta veya kullanıcı adı " +
                    "boş bırakılamaz"
            return
        }
        if (password.isBlank()) {
            errorMessage.value =
                "Şifre boş bırakılamaz"
            return
        }

        viewModelScope.launch {
            isLoading.value = true
            errorMessage.value = null

            val result = authRepository.login(
                emailOrUsername =
                    emailOrUsername.trim(),
                password = password
            )

            result.fold(
                onSuccess = { profile ->
                    currentProfile.value = profile
                    isLoggedIn.value = true
                },
                onFailure = { e ->
                    errorMessage.value = e.message
                }
            )
            isLoading.value = false
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logoutSuspend()
            isLoggedIn.value = false
            currentProfile.value = null
        }
    }

    fun sendPasswordReset(email: String) {
        viewModelScope.launch {
            authRepository.sendPasswordReset(email)
        }
    }

    fun clearError() {
        errorMessage.value = null
    }

    private fun loadProfile() {
        viewModelScope.launch {
            authRepository.getUserProfile()
                .onSuccess { profile ->
                    currentProfile.value = profile
                    isLoggedIn.value = true
                }
                .onFailure {
                    authRepository.logoutSuspend()
                    currentProfile.value = null
                    isLoggedIn.value = false
                }
        }
    }

    private fun validateSession() {
        if (!authRepository.isLoggedIn) {
            isLoggedIn.value = false
            currentProfile.value = null
            return
        }
        loadProfile()
    }
}
