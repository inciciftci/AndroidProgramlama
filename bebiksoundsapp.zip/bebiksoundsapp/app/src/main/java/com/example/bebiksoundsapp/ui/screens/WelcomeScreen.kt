package com.example.bebiksoundsapp.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.bebiksoundsapp.ui.Screen

@Composable
fun WelcomeScreen(navController: NavController) {

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF120810),
                        Color(0xFF1C1018),
                        Color(0xFF120810)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 28.dp,
                    vertical = 52.dp
                ),
            horizontalAlignment =
                Alignment.CenterHorizontally,
            verticalArrangement =
                Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment =
                    Alignment.CenterHorizontally,
                verticalArrangement =
                    Arrangement.spacedBy(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .wrapContentHeight()
            ) {
                Spacer(Modifier.height(40.dp))

                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF8A3055),
                                    Color(0xFF6B2040)
                                )
                            )
                        ),
                    contentAlignment =
                        Alignment.Center
                ) {
                    Text(
                        text = "\uD83C\uDF19",
                        fontSize = 48.sp
                    )
                }

                Text(
                    text = "Bebik Sounds",
                    fontSize = 32.sp,
                    fontWeight =
                        FontWeight.ExtraBold,
                    color = Color(0xFFC8A8B4)
                )

                Text(
                    text = "Bebeğiniz için\nhuzurlu sesler",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF8A6070),
                    textAlign = TextAlign.Center,
                    lineHeight = 24.sp
                )
            }

            Column(
                verticalArrangement =
                    Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = {
                        navController.navigate(
                            Screen.Register.route
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults
                        .buttonColors(
                            containerColor =
                                Color(0xFF6B2040)
                        ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "Hesap Oluştur",
                        fontSize = 16.sp,
                        fontWeight =
                            FontWeight.ExtraBold,
                        color = Color(0xFFF0D0DC)
                    )
                }

                OutlinedButton(
                    onClick = {
                        navController.navigate(
                            Screen.Login.route
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    border = BorderStroke(
                        1.5.dp,
                        Color(0xFF6B2040)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "Giriş Yap",
                        fontSize = 16.sp,
                        fontWeight =
                            FontWeight.ExtraBold,
                        color = Color(0xFFC8A8B4)
                    )
                }

                TextButton(
                    onClick = {
                        navController.navigate(
                            Screen.Main.route
                        ) {
                            popUpTo(
                                Screen.Welcome.route
                            ) { inclusive = true }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text(
                        text = "Misafir olarak devam et",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF5A3848)
                    )
                }
            }
        }
    }
}
