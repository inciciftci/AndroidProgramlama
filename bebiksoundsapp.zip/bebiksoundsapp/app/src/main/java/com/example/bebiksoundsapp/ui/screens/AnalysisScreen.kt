package com.example.bebiksoundsapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIos
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.bebiksoundsapp.ui.SoundViewModel

@Composable
fun AnalysisScreen(navController: NavController, viewModel: SoundViewModel) {
    LaunchedEffect(Unit) {
        viewModel.loadAnalysis()
    }
    val suggestion by viewModel
        .sleepSuggestion.collectAsState()
    val sessionCount by viewModel
        .sessionCount.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF120810))
            .padding(
                top = 52.dp,
                start = 22.dp,
                end = 22.dp,
                bottom = 32.dp
            )
    ) {
        // Geri butonu + başlık
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 28.dp),
            verticalAlignment =
                Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1C1018))
                    .clickable {
                        navController.popBackStack()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default
                        .ArrowBackIos,
                    contentDescription = "Geri",
                    tint = Color(0xFF8A6070),
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Text(
                text = "Uyku Analizi",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFC8A8B4)
            )
        }

        // Toplam oturum kartı
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF1C1018))
                .padding(18.dp)
        ) {
            Row(
                verticalAlignment =
                    Alignment.CenterVertically,
                horizontalArrangement =
                    Arrangement.spacedBy(14.dp)
            ) {
                Text("📊", fontSize = 32.sp)
                Column {
                    Text(
                        text = "$sessionCount oturum",
                        fontSize = 20.sp,
                        fontWeight =
                            FontWeight.ExtraBold,
                        color = Color(0xFFC8A8B4)
                    )
                    Text(
                        text = "kayıt edildi",
                        fontSize = 12.sp,
                        color = Color(0xFF8A6070)
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Öneri kartı
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF2E1828))
                .border(
                    1.5.dp,
                    Color(0xFF6B2040),
                    RoundedCornerShape(20.dp)
                )
                .padding(20.dp)
        ) {
            Column(
                verticalArrangement =
                    Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "🤖 Yapay Zeka Önerisi",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.5.sp,
                    color = Color(0xFFA87088)
                )
                Text(
                    text = suggestion ?:
                        "Analiz için daha fazla\n" +
                        "oturum gerekiyor...",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFC8A8B4),
                    lineHeight = 24.sp
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // Yeterli veri yoksa motivasyon mesajı
        if (sessionCount < 5) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF1C1018))
                    .padding(16.dp)
            ) {
                Text(
                    text = "💡 Her kullanımdan " +
                        "sonra 'Bebek uyudu mu?' " +
                        "sorusunu cevapla — " +
                        "yapay zeka bebeğinin " +
                        "profilini öğrensin.",
                    fontSize = 12.sp,
                    color = Color(0xFF8A6070),
                    lineHeight = 20.sp
                )
            }
        }
    }
}
