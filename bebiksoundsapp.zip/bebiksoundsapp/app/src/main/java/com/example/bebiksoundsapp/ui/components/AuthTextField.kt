package com.example.bebiksoundsapp.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions

@Composable
fun AuthTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    modifier: Modifier = Modifier,
    prefix: String? = null,
    isPassword: Boolean = false,
    passwordVisible: Boolean = false,
    onPasswordToggle: (() -> Unit)? = null,
    keyboardType: KeyboardType =
        KeyboardType.Text
) {
    Column(
        verticalArrangement =
            Arrangement.spacedBy(6.dp),
        modifier = modifier
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF8A6070)
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = {
                Text(
                    text = placeholder,
                    fontSize = 14.sp,
                    color = Color(0xFF5A3848)
                )
            },
            prefix = prefix?.let {
                {
                    Text(
                        text = it,
                        fontSize = 14.sp,
                        color = Color(0xFF8A3055)
                    )
                }
            },
            visualTransformation =
                if (isPassword && !passwordVisible)
                    PasswordVisualTransformation()
                else VisualTransformation.None,
            trailingIcon =
                if (isPassword) {
                    {
                        IconButton(
                            onClick = {
                                onPasswordToggle
                                    ?.invoke()
                            }
                        ) {
                            Icon(
                                imageVector =
                                    if (passwordVisible)
                                        Icons.Default
                                            .Visibility
                                    else
                                        Icons.Default
                                            .VisibilityOff,
                                contentDescription =
                                    null,
                                tint = Color(0xFF5A3848)
                            )
                        }
                    }
                } else null,
            keyboardOptions = KeyboardOptions(
                keyboardType = keyboardType
            ),
            colors = OutlinedTextFieldDefaults
                .colors(
                    focusedBorderColor =
                        Color(0xFF6B2040),
                    unfocusedBorderColor =
                        Color(0xFF3A1228),
                    focusedTextColor =
                        Color(0xFFC8A8B4),
                    unfocusedTextColor =
                        Color(0xFFC8A8B4),
                    cursorColor =
                        Color(0xFF8A3055),
                    focusedContainerColor =
                        Color(0xFF1C1018),
                    unfocusedContainerColor =
                        Color(0xFF1C1018)
                ),
            shape = RoundedCornerShape(14.dp),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
