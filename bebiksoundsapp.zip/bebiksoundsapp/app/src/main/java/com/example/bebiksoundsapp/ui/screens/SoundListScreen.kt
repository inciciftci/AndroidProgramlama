package com.example.bebiksoundsapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBackIos
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.bebiksoundsapp.ui.AppMode
import com.example.bebiksoundsapp.ui.CategoryType
import com.example.bebiksoundsapp.ui.Screen
import com.example.bebiksoundsapp.ui.SoundItem
import com.example.bebiksoundsapp.ui.SoundViewModel
import com.example.bebiksoundsapp.ui.theme.Accent
import com.example.bebiksoundsapp.ui.theme.AccentDim
import com.example.bebiksoundsapp.ui.theme.AccentLight
import com.example.bebiksoundsapp.ui.theme.BgColor
import com.example.bebiksoundsapp.ui.theme.ChildBg1
import com.example.bebiksoundsapp.ui.theme.ChildBg2
import com.example.bebiksoundsapp.ui.theme.ChildBg3
import com.example.bebiksoundsapp.ui.theme.ChildBg4
import com.example.bebiksoundsapp.ui.theme.ChildBorder
import com.example.bebiksoundsapp.ui.theme.ChildOrange
import com.example.bebiksoundsapp.ui.theme.ChildOrangeLight
import com.example.bebiksoundsapp.ui.theme.ChildShadow
import com.example.bebiksoundsapp.ui.theme.ChildSurface
import com.example.bebiksoundsapp.ui.theme.ChildSurfaceAccent
import com.example.bebiksoundsapp.ui.theme.ChildSurfaceSoft
import com.example.bebiksoundsapp.ui.theme.ChildTextDark
import com.example.bebiksoundsapp.ui.theme.ChildTextMid
import com.example.bebiksoundsapp.ui.theme.Surface1
import com.example.bebiksoundsapp.ui.theme.Surface2
import com.example.bebiksoundsapp.ui.theme.TextHigh
import com.example.bebiksoundsapp.ui.theme.TextLow
import com.example.bebiksoundsapp.ui.theme.TextMid

@Composable
fun SoundListScreen(navController: NavController, viewModel: SoundViewModel) {
    val category by viewModel.selectedCategory.collectAsState()
    val playingItem by viewModel.playingItem.collectAsState()
    val favoriteItems by viewModel.favoriteItems.collectAsState()
    val appMode by viewModel.appMode.collectAsState()
    val isParentMode = appMode == AppMode.PARENT

    val bgColors = if (isParentMode) listOf(BgColor, BgColor) else listOf(ChildBg1, ChildBg2, ChildBg3, ChildBg4)
    val surfaceColor = if (isParentMode) Surface1 else ChildSurface
    val accentColor = if (isParentMode) Accent else ChildOrange
    val titleTextColor = if (isParentMode) TextHigh else ChildTextDark
    val bodyTextColor = if (isParentMode) TextMid else ChildTextMid
    val mutedTextColor = if (isParentMode) TextLow else ChildTextMid

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = bgColors
                )
            )
            .padding(top = 36.dp, start = 22.dp, end = 22.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(surfaceColor)
                    .clickable { navController.popBackStack() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBackIos,
                    contentDescription = "Geri",
                    tint = bodyTextColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Column {
                Text(
                    text = category?.name ?: "",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = titleTextColor
                )
                Text(
                    text = if (category?.type == CategoryType.FAVORITES) 
                        "${favoriteItems.size} favori"
                    else 
                        "${category?.items?.size ?: 0} ses",
                    fontSize = 11.sp,
                    color = bodyTextColor
                )
            }
        }

        if (category?.type == CategoryType.SOUND_LIST) {
            NowPlayingMiniCard(
                playingItem = playingItem,
                categoryIcon = category?.emoji ?: "",
                isParentMode = isParentMode,
                onCardClick = {
                    navController.navigate(Screen.Player.route)
                },
                onPlayClick = { viewModel.togglePlay() }
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(category?.items ?: emptyList()) { index, item ->
                    val isPlaying = playingItem?.id == item.id
                    val isFav = favoriteItems.any { it.id == item.id }
                    SoundItemRow(
                        item = item,
                        index = index,
                        isPlaying = isPlaying,
                        isParentMode = isParentMode,
                        isFavorite = isFav,
                        onRowClick = {
                            viewModel.selectItem(item)
                            navController.navigate(Screen.Player.route)
                        },
                        onFavoriteClick = {
                            viewModel.toggleFavorite(item)
                        }
                    )
                }
            }
        }

        // FAVORİLER
        if (category?.type == CategoryType.FAVORITES) {
            if (favoriteItems.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(top = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🤍", fontSize = 48.sp)
                        Spacer(Modifier.height(16.dp))
                        Text(
                            "Henüz favori yok",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = titleTextColor
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Bir sesi çalarken kalp ikonuna\nbasarak favorilere ekleyebilirsiniz.",
                            fontSize = 12.sp,
                            color = bodyTextColor,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(favoriteItems) { index, item ->
                        SoundItemRow(
                            item = item,
                            index = index,
                            isPlaying = playingItem?.id == item.id,
                            isParentMode = isParentMode,
                            isFavorite = true,
                            onRowClick = {
                                viewModel.selectItem(item)
                                navController.navigate(Screen.Player.route)
                            },
                            onFavoriteClick = { viewModel.toggleFavorite(item) }
                        )
                    }
                }
            }
        }

        // UYKU TEKNİKLERİ
        if (category?.type == CategoryType.SLEEP_TIPS) {
            val techniques = listOf(
                Triple("Klasik", "4-7-8 Nefes Tekniği",
                    "4 saniye nefes al, 7 saniye tut, 8 saniyede ver. Bebeğinizin sinir sistemini sakinleştirmek için ideal."),
                Triple("Popüler", "Beyaz Gürültü Yöntemi",
                    "Sürekli beyaz gürültü, anne karnındaki sesi taklit eder. 30-60 dakika arka planda çalın."),
                Triple("Uzman Önerir", "5S Yöntemi",
                    "Sarma, yan yatırma, sallama, emzirme ve ses. Bu 5 adım bebeği hızlıca sakinleştirir."),
                Triple("Doğal", "Doğa Sesi ile Uyku",
                    "Yağmur veya okyanus sesi çalarken odayı karartın. Rutin haline getirmek uyku kalitesini artırır.")
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(techniques) { (badge, name, desc) ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(surfaceColor)
                            .padding(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(accentColor.copy(alpha = 0.12f))
                                .padding(horizontal = 9.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = badge.uppercase(),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp,
                                color = mutedTextColor
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(name, fontSize = 14.sp,
                            fontWeight = FontWeight.Bold, color = titleTextColor)
                        Spacer(Modifier.height(5.dp))
                        Text(desc, fontSize = 11.sp,
                            color = bodyTextColor, lineHeight = 18.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SoundItemRow(
    item: SoundItem,
    index: Int,
    isPlaying: Boolean,
    isParentMode: Boolean,
    isFavorite: Boolean,
    onRowClick: () -> Unit,
    onFavoriteClick: () -> Unit
) {
    val surfaceColor = if (isParentMode) Surface1 else ChildSurface
    val surfaceSoftColor = if (isParentMode) Surface2 else ChildSurfaceSoft
    val borderColor = if (isParentMode) Accent else ChildBorder
    val accentColor = if (isParentMode) AccentLight else ChildOrange
    val titleTextColor = if (isParentMode) TextHigh else ChildTextDark
    val bodyTextColor = if (isParentMode) TextMid else ChildTextMid

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isPlaying) surfaceSoftColor else surfaceColor)
            .border(
                width = if (isPlaying) 1.5.dp else 0.dp,
                color = if (isPlaying) borderColor else Color.Transparent,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onRowClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "${index + 1}",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isPlaying) accentColor else bodyTextColor,
            modifier = Modifier.width(20.dp),
            textAlign = TextAlign.Center
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.name,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = titleTextColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = item.duration,
                fontSize = 11.sp,
                color = bodyTextColor
            )
        }
        IconButton(
            onClick = onFavoriteClick,
            modifier = Modifier.size(28.dp)
        ) {
            Icon(
                imageVector = if (isFavorite)
                    Icons.Filled.Favorite
                else
                    Icons.Outlined.FavoriteBorder,
                contentDescription = null,
                tint = if (isFavorite) titleTextColor else bodyTextColor,
                modifier = Modifier.size(16.dp)
            )
        }
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(
                    if (isPlaying) accentColor else Color.Transparent
                )
                .border(
                    1.5.dp,
                    if (isPlaying) accentColor else bodyTextColor,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = if (isPlaying) Color.White else bodyTextColor,
                modifier = Modifier.size(10.dp)
            )
        }
    }
}

@Composable
fun NowPlayingMiniCard(
    playingItem: SoundItem?,
    categoryIcon: String,
    isParentMode: Boolean,
    onCardClick: () -> Unit,
    onPlayClick: () -> Unit
) {
    val surfaceColor = if (isParentMode) Surface1 else ChildSurface
    val borderColor = if (isParentMode) Accent else ChildBorder
    val accentSoftColor = if (isParentMode) AccentDim else ChildSurfaceAccent
    val accentColors = if (isParentMode) listOf(Accent, AccentLight) else listOf(ChildOrangeLight, ChildOrange)
    val titleTextColor = if (isParentMode) TextHigh else ChildTextDark
    val bodyTextColor = if (isParentMode) TextMid else ChildTextMid
    val shadowColor = if (isParentMode) Accent else ChildShadow

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 20.dp)
            .shadow(
                elevation = 8.dp,
                shape = RoundedCornerShape(20.dp),
                ambientColor = shadowColor.copy(alpha = 0.2f),
                spotColor = shadowColor.copy(alpha = 0.2f)
            )
            .clip(RoundedCornerShape(20.dp))
            .background(surfaceColor)
            .border(
                width = 1.5.dp,
                color = borderColor.copy(alpha = 0.4f),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable { onCardClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(accentSoftColor),
            contentAlignment = Alignment.Center
        ) {
            Text(text = categoryIcon, fontSize = 18.sp)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "ŞU AN ÇALIYOR",
                fontSize = 9.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp,
                color = bodyTextColor
            )
            Text(
                text = playingItem?.name ?: "—",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = titleTextColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(
                    brush = Brush.linearGradient(
                        colors = accentColors
                    )
                )
                .clickable { onPlayClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
