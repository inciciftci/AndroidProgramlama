package com.example.bebiksoundsapp.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.ripple.LocalRippleTheme
import androidx.compose.material.ripple.RippleAlpha
import androidx.compose.material.ripple.RippleTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = Accent,
    onPrimary = TextHigh,
    primaryContainer = AccentDim,
    onPrimaryContainer = TextHigh,
    secondary = AccentLight,
    onSecondary = TextHigh,
    background = BgColor,
    onBackground = TextHigh,
    surface = Surface1,
    onSurface = TextHigh,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextMid,
    outline = Accent
)

@Immutable
private object BebeSesRippleTheme : RippleTheme {
    @Composable
    override fun defaultColor() = AccentLight

    @Composable
    override fun rippleAlpha(): RippleAlpha = RippleAlpha(
        pressedAlpha = 0.15f,
        focusedAlpha = 0.15f,
        draggedAlpha = 0.15f,
        hoveredAlpha = 0.15f
    )
}

@Composable
fun BebeSesTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = BgColor.toArgb()
            window.navigationBarColor = BgColor.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.setDecorFitsSystemWindows(window, true)
        }
    }

    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = AppTypography
    ) {
        CompositionLocalProvider(
            LocalRippleTheme provides BebeSesRippleTheme,
            content = content
        )
    }
}
