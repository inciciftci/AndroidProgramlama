package com.example.bebiksoundsapp.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.foundation.Image
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.annotation.DrawableRes
import androidx.navigation.NavController
import kotlin.math.roundToInt
import com.example.bebiksoundsapp.R
import com.example.bebiksoundsapp.model.SoundCategory
import com.example.bebiksoundsapp.ui.AppMode
import com.example.bebiksoundsapp.ui.Screen
import com.example.bebiksoundsapp.ui.SoundViewModel
import com.example.bebiksoundsapp.ui.components.ModeToggle

private val oyunCategory = SoundCategory(
    101,
    "Oyun",
    "🎪",
    Color(0xFFFFD060)
)
private val dansCategory = SoundCategory(
    102,
    "Dans",
    "💃",
    Color(0xFFFF80D0)
)
private val hayvanCategory = SoundCategory(
    103,
    "Hayvanlar",
    "🌊",
    Color(0xFF40B0E0)
)
private val ormanCategory = SoundCategory(
    104,
    "Orman",
    "🌿",
    Color(0xFF60C060)
)

@Composable
fun ChildScreen(
    navController: NavController,
    viewModel: SoundViewModel
) {
    val appMode by viewModel.appMode.collectAsState()
    val playingItem by viewModel.playingItem.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.progress.collectAsState()
    var isTimerSet by remember { mutableStateOf(false) }
    var isTimerPanelExpanded by remember { mutableStateOf(true) }
    val timerMinutes by viewModel.timerMinutes.collectAsState()
    val timerRemainingSeconds by viewModel.timerRemainingSeconds.collectAsState()
    val displayMinutes = timerRemainingSeconds / 60
    val displaySeconds = timerRemainingSeconds % 60
    val displayTime = String.format("%02d:%02d", displayMinutes, displaySeconds)

    BackHandler {
        viewModel.setAppMode(AppMode.PARENT)
    }

    val isPlayTimeUp by viewModel.isPlayTimeUp.collectAsState()

    if (isPlayTimeUp) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = Color(0xFFFFF8E8),
            title = {
                Column(
                    horizontalAlignment =
                        Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "⏰", fontSize = 48.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Oyun Süresi Doldu!",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF5A3820),
                        textAlign = TextAlign.Center
                    )
                }
            },
            text = {
                Text(
                    text = "Oyun zamanı bitti.\nNe yapmak istersiniz?",
                    fontSize = 13.sp,
                    color = Color(0xFFA07848),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                // Ebeveyn moduna dön
                Button(
                    onClick = {
                        viewModel.isPlayTimeUp.value = false
                        viewModel.setAppMode(AppMode.PARENT)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFE07020)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        "Oyunu Bitir",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                // Süre uzat
                OutlinedButton(
                    onClick = {
                        viewModel.isPlayTimeUp.value = false
                        viewModel.adjustTimer(15)
                        viewModel.confirmTimer()
                    },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        1.5.dp, Color(0xFFE07020)
                    )
                ) {
                    Text(
                        "+15 dk uzat",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFE07020)
                    )
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFFF8E8),
                        Color(0xFFFFF3D8),
                        Color(0xFFF5FFE8),
                        Color(0xFFFFFBF0)
                    )
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(bottom = 20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    top = 36.dp,
                    start = 18.dp,
                    end = 18.dp,
                    bottom = 6.dp
                ),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "☀️", fontSize = 40.sp)

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(100.dp))
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFF9A40),
                                    Color(0xFFE07020)
                                )
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "🎮 OYUN MODU",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp,
                        color = Color.White
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "Oyun Zamanı! 🎵",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF5A3820)
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFF3D0))
                        .border(1.5.dp, Color(0xFFD4A030), CircleShape)
                        .clickable {
                            navController.navigate(Screen.Profile.route)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Profil",
                        tint = Color(0xFFE07020),
                        modifier = Modifier.size(20.dp)
                    )
                }

                ModeToggle(
                    isChildMode = appMode == AppMode.CHILD,
                    onToggle = {
                        viewModel.toggleAppMode()
                        navController.popBackStack()
                    },
                    trackActiveColor = Color(0xFFFFE8A0),
                    trackActiveBorder = Color(0xFFD4A030),
                    thumbActiveColor = Color(0xFFE07020),
                    thumbIconTint = Color(0xFFFFFFFF),
                    labelColor = Color(0xFFE07020),
                    labelInactiveColor = Color(0xFFA07848)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = 18.dp,
                    end = 18.dp,
                    top = 12.dp,
                    bottom = 14.dp
                )
                .clip(RoundedCornerShape(24.dp))
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFFFFBF0),
                            Color(0xFFFFF8E0)
                        )
                    )
                )
                .border(
                    2.dp,
                    Color(0xFFD29638).copy(alpha = 0.35f),
                    RoundedCornerShape(24.dp)
                )
                .clickable {
                    navController.navigate(Screen.Player.route)
                }
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFFE8A0),
                                    Color(0xFFFFD060)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🎪", fontSize = 26.sp)
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "🎵 ŞU AN ÇALIYOR",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp,
                        color = Color(0xFFC4904A)
                    )
                    Text(
                        text = playingItem?.name ?: "—",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF5A3820),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFF9A40),
                                    Color(0xFFE07020)
                                )
                            )
                        )
                        .clickable(
                            interactionSource = remember {
                                MutableInteractionSource()
                            },
                            indication = null
                        ) { viewModel.togglePlay() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) {
                            Icons.Default.Pause
                        } else {
                            Icons.Default.PlayArrow
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(10.dp)),
                color = Color(0xFFE07020),
                trackColor = Color(0xFFB47828).copy(alpha = 0.12f)
            )
        }

        Text(
            text = "🎪 KATEGORİLER",
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 2.sp,
            color = Color(0xFFA07848),
            modifier = Modifier.padding(
                start = 18.dp,
                bottom = 10.dp
            )
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ChildCategoryCard(
                emoji = "🎪",
                name = "Oyun",
                bgColors = listOf(
                    Color(0xFFFFF3D0),
                    Color(0xFFFFE8A0)
                ),
                iconBgColors = listOf(
                    Color(0xFFFFD060),
                    Color(0xFFF0A820)
                ),
                onClick = {
                    viewModel.openCategory(oyunCategory)
                    navController.navigate(Screen.SoundList.route)
                },
                modifier = Modifier.weight(1f)
            )
            ChildCategoryCard(
                emoji = "💃",
                name = "Dans",
                bgColors = listOf(
                    Color(0xFFFFE8F8),
                    Color(0xFFFFD0F0)
                ),
                iconBgColors = listOf(
                    Color(0xFFFF80D0),
                    Color(0xFFD040A0)
                ),
                onClick = {
                    viewModel.openCategory(dansCategory)
                    navController.navigate(Screen.SoundList.route)
                },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ChildCategoryCard(
                emoji = "🌊",
                iconRes = R.drawable.hayvanlar,
                name = "Hayvanlar",
                bgColors = listOf(
                    Color(0xFFE0F8FF),
                    Color(0xFFC0EEFF)
                ),
                iconBgColors = listOf(
                    Color(0xFF40B0E0),
                    Color(0xFF1070A0)
                ),
                onClick = {
                    viewModel.openCategory(hayvanCategory)
                    navController.navigate(Screen.SoundList.route)
                },
                modifier = Modifier.weight(1f)
            )
            ChildCategoryCard(
                emoji = "🌿",
                name = "Orman",
                bgColors = listOf(
                    Color(0xFFE8FFE8),
                    Color(0xFFC8F0C8)
                ),
                iconBgColors = listOf(
                    Color(0xFF60C060),
                    Color(0xFF308030)
                ),
                onClick = {
                    viewModel.openCategory(ormanCategory)
                    navController.navigate(Screen.SoundList.route)
                },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Favoriler — görsel ağırlıklı, tek satır
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFFFF3D0),
                            Color(0xFFFFE8A0)
                        )
                    )
                )
                .clickable {
                    navController.navigate(Screen.SoundList.route)
                }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(text = "⭐", fontSize = 28.sp)
            Text(
                text = "Favorilerim",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF5A3820),
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "›",
                fontSize = 22.sp,
                color = Color(0xFFD4904A)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Alt kontrol butonları — ÇOK BÜYÜK, çocuk dostu
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Önceki
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color(0xFFE8F0FF),
                                Color(0xFFD0E0FF)
                            )
                        )
                    )
                    .clickable { viewModel.playPrevious() }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment =
                        Alignment.CenterHorizontally,
                    verticalArrangement =
                        Arrangement.spacedBy(4.dp)
                ) {
                    Text(text = "⏮", fontSize = 30.sp)
                    Text(
                        text = "Önceki",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF4070D0)
                    )
                }
            }

            // Karıştır
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color(0xFFE8FFE8),
                                Color(0xFFC8F0C8)
                            )
                        )
                    )
                    .clickable { /* shuffle */ }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment =
                        Alignment.CenterHorizontally,
                    verticalArrangement =
                        Arrangement.spacedBy(4.dp)
                ) {
                    Text(text = "🔀", fontSize = 30.sp)
                    Text(
                        text = "Karıştır",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF40A040)
                    )
                }
            }

            // Sonraki
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color(0xFFFFE8E8),
                                Color(0xFFFFD0D0)
                            )
                        )
                    )
                    .clickable { viewModel.playNext() }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment =
                        Alignment.CenterHorizontally,
                    verticalArrangement =
                        Arrangement.spacedBy(4.dp)
                ) {
                    Text(text = "⏭", fontSize = 30.sp)
                    Text(
                        text = "Sonraki",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFD04040)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (isTimerPanelExpanded) {
            // AÇIK PANEL — süre ayarlama
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF5A3820).copy(alpha = 0.08f))
                    .border(
                        1.dp,
                        Color(0xFF5A3820).copy(alpha = 0.12f),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = "🔒", fontSize = 14.sp)
                    Text(
                        text = "Ebeveyn — Oyun Süresi",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFA07848)
                    )
                }

                // Süre seçici — büyük, kolay ayarlanır
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // − butonu
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                Color(0xFFB47828).copy(alpha = 0.15f)
                            )
                            .clickable { viewModel.adjustTimer(-5) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "−", fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFD4904A)
                        )
                    }

                    Spacer(Modifier.width(20.dp))

                    // Süre göstergesi — büyük
                    Column(
                        horizontalAlignment =
                            Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = displayTime,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF5A3820)
                        )
                        Text(
                            text = "dk:sn",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFA07848)
                        )
                    }

                    Spacer(Modifier.width(20.dp))

                    // + butonu
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFFFF9A40),
                                        Color(0xFFE07020)
                                    )
                                )
                            )
                            .clickable { viewModel.adjustTimer(5) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "+", fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }

                // BAŞLAT butonu
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFF9A40),
                                    Color(0xFFE07020)
                                )
                            )
                        )
                        .clickable {
                            isTimerSet = true
                            isTimerPanelExpanded = false
                            viewModel.confirmTimer()
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "✓ Süreyi Başlat",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
            }
        } else if (isTimerSet) {
            // KÜÇÜLMüŞ PANEL — sadece kalan süre görünür
            var offsetX by remember { mutableFloatStateOf(0f) }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color(0xFFFFF3D0),
                                Color(0xFFFFE8A0)
                            )
                        )
                    )
                    .border(
                        1.5.dp,
                        Color(0xFFD4A030).copy(alpha = 0.4f),
                        RoundedCornerShape(14.dp)
                    )
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                if (offsetX < -80f) {
                                    isTimerPanelExpanded = true
                                }
                                offsetX = 0f
                            },
                            onHorizontalDrag = { _, dragAmount ->
                                offsetX += dragAmount
                            }
                        )
                    }
                    .offset { IntOffset(offsetX.roundToInt(), 0) }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = "🔒", fontSize = 16.sp)

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "OYUN SÜRESİ",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp,
                        color = Color(0xFFA07848)
                    )
                    Text(
                        text = "$displayTime kaldı",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF5A3820)
                    )
                }

                // Kaydır ipucu — animasyonlu ok
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "düzenle",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFA07848).copy(alpha = 0.7f)
                    )
                    Text(
                        text = "◀",
                        fontSize = 11.sp,
                        color = Color(0xFFE07020).copy(alpha = 0.8f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Footer
        Text(
            text = "🦁 🦋 🐘 🌿 — Oyna, gülen, büyü! 🎵",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFC4A060),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun ChildCategoryCard(
    emoji: String,
    @DrawableRes iconRes: Int? = null,
    name: String,
    bgColors: List<Color>,
    iconBgColors: List<Color>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = bgColors
                )
            )
            .clickable { onClick() }
            .padding(top = 18.dp, bottom = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // İkon kutusu — ÇOK BÜYÜK
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(
                    brush = Brush.linearGradient(
                        colors = iconBgColors
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            if (iconRes != null) {
                Image(
                    painter = painterResource(id = iconRes),
                    contentDescription = name,
                    modifier = Modifier.size(56.dp),
                    contentScale = ContentScale.Fit
                )
            } else {
                Text(
                    text = emoji,
                    fontSize = 36.sp
                )
            }
        }
        // İsim — kısa ve büyük
        Text(
            text = name,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF5A3820),
            textAlign = TextAlign.Center
        )
    }
}
