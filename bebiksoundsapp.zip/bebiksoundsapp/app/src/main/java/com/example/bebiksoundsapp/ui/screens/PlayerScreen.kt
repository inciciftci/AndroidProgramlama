package com.example.bebiksoundsapp.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.bebiksoundsapp.ui.AppMode
import com.example.bebiksoundsapp.ui.SoundViewModel
import com.example.bebiksoundsapp.ui.theme.Accent
import com.example.bebiksoundsapp.ui.theme.AccentLight
import com.example.bebiksoundsapp.ui.theme.BgColor
import com.example.bebiksoundsapp.ui.theme.ChildBg1
import com.example.bebiksoundsapp.ui.theme.ChildBg2
import com.example.bebiksoundsapp.ui.theme.ChildBg3
import com.example.bebiksoundsapp.ui.theme.ChildBg4
import com.example.bebiksoundsapp.ui.theme.ChildOrange
import com.example.bebiksoundsapp.ui.theme.ChildOrangeLight
import com.example.bebiksoundsapp.ui.theme.ChildShadow
import com.example.bebiksoundsapp.ui.theme.ChildSurface
import com.example.bebiksoundsapp.ui.theme.ChildSurfaceSoft
import com.example.bebiksoundsapp.ui.theme.ChildTextDark
import com.example.bebiksoundsapp.ui.theme.ChildTextMid
import com.example.bebiksoundsapp.ui.theme.Surface1
import com.example.bebiksoundsapp.ui.theme.Surface2
import com.example.bebiksoundsapp.ui.theme.TextHigh
import com.example.bebiksoundsapp.ui.theme.TextMid

@Composable
fun PlayerScreen(navController: NavController, viewModel: SoundViewModel) {
    val category by viewModel.selectedCategory.collectAsState()
    val playingItem by viewModel.playingItem.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val isFavorite by viewModel.isFavorite.collectAsState()
    val appMode by viewModel.appMode.collectAsState()
    val isParentMode = appMode == AppMode.PARENT

    val bgColors = if (isParentMode) listOf(BgColor, BgColor) else listOf(ChildBg1, ChildBg2, ChildBg3, ChildBg4)
    val surfaceColor = if (isParentMode) Surface1 else ChildSurface
    val surfaceSoftColor = if (isParentMode) Surface2 else ChildSurfaceSoft
    val accentColor = if (isParentMode) Accent else ChildOrange
    val accentLightColor = if (isParentMode) AccentLight else ChildOrangeLight
    val titleTextColor = if (isParentMode) TextHigh else ChildTextDark
    val bodyTextColor = if (isParentMode) TextMid else ChildTextMid
    val shadowColor = if (isParentMode) Accent else ChildShadow

    val scale by animateFloatAsState(
        targetValue = if (isPlaying) 1.03f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = bgColors
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    top = 52.dp,
                    bottom = 48.dp,
                    start = 28.dp,
                    end = 28.dp
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 36.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(surfaceColor)
                        .clickable { navController.popBackStack() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Kapat",
                        tint = bodyTextColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Text(
                    text = category?.name ?: "",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp,
                    color = bodyTextColor
                )
                Box(modifier = Modifier.size(36.dp))
            }

            Box(
                modifier = Modifier
                    .size(196.dp)
                    .align(Alignment.CenterHorizontally)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .shadow(
                        elevation = 20.dp,
                        shape = RoundedCornerShape(28.dp),
                        ambientColor = shadowColor.copy(alpha = 0.2f),
                        spotColor = shadowColor.copy(alpha = 0.2f)
                    )
                    .clip(RoundedCornerShape(28.dp))
                    .background(surfaceSoftColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = category?.emoji ?: "🎵",
                    fontSize = 70.sp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 22.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = playingItem?.name ?: "",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = titleTextColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${category?.name ?: ""} · ${playingItem?.duration ?: ""}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = bodyTextColor
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(surfaceColor)
                        .clickable { viewModel.toggleFavorite(playingItem) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isFavorite)
                            Icons.Filled.Favorite
                        else
                            Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favoriye ekle",
                        tint = if (isFavorite) titleTextColor else bodyTextColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(10.dp)),
                color = accentColor,
                trackColor = surfaceSoftColor
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "0:00",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = bodyTextColor
                )
                Text(
                    text = playingItem?.duration ?: "0:00",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = bodyTextColor
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .clickable { viewModel.playPrevious() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Önceki",
                        tint = titleTextColor,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(66.dp)
                        .shadow(
                            elevation = 8.dp,
                            shape = CircleShape,
                            ambientColor = shadowColor.copy(alpha = 0.35f),
                            spotColor = shadowColor.copy(alpha = 0.35f)
                        )
                        .clip(CircleShape)
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(accentLightColor, accentColor)
                            )
                        )
                        .clickable { viewModel.togglePlay() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying)
                            Icons.Default.Pause
                        else
                            Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Durdur" else "Oynat",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .clickable { viewModel.playNext() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Sonraki",
                        tint = titleTextColor,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))
        }
    }
}
