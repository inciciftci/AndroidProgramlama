package com.example.bebiksoundsapp.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bebiksoundsapp.model.SoundCategory
import com.example.bebiksoundsapp.ui.theme.*

@Composable
fun SoundGrid(
    categories: List<SoundCategory>,
    selectedCategory: SoundCategory?,
    onSelect: (SoundCategory) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        // İlk Satır: Ninniler, Klasik Müzik, Beyaz Gürültü
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            categories.take(3).forEach { category ->
                SoundCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(122.dp),
                    category = category,
                    isSelected = category == selectedCategory,
                    onClick = { onSelect(category) }
                )
            }
        }
        
        // İkinci Satır: Doğa, Favoriler, Uyku Teknikleri
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            categories.drop(3).take(3).forEach { category ->
                SoundCard(
                    modifier = Modifier
                        .weight(1f)
                        .height(122.dp),
                    category = category,
                    isSelected = category == selectedCategory,
                    onClick = { onSelect(category) }
                )
            }
        }
    }
}

@Composable
fun SoundCard(
    modifier: Modifier = Modifier,
    category: SoundCategory,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .clickable { onClick() }
            .background(
                if (isSelected) Surface2 else Surface1
            )
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = if (isSelected) Accent else Color.Transparent,
                shape = RoundedCornerShape(26.dp)
            )
            .padding(top = 20.dp, bottom = 16.dp, start = 10.dp, end = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(color = category.iconBackground, shape = RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = category.emoji, fontSize = 24.sp)
        }
        
        Spacer(modifier = Modifier.height(10.dp))
        
        Text(
            text = category.name,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isSelected) Color(0xFFA87088) else TextMid,
            maxLines = 1
        )
        
        if (isSelected) {
            Spacer(modifier = Modifier.height(5.dp))
            Box(modifier = Modifier.size(6.dp).background(AccentLight, CircleShape))
        }
    }
}
