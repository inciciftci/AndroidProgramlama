package com.example.bebiksoundsapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIos
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.bebiksoundsapp.ui.Screen
import com.example.bebiksoundsapp.ui.components.AuthTextField
import com.example.bebiksoundsapp.viewmodel.AuthViewModel

@Composable
fun LoginScreen(navController: NavController) {
    val authViewModel: AuthViewModel = viewModel()
    val isLoading by authViewModel
        .isLoading.collectAsState()
    val errorMessage by authViewModel
        .errorMessage.collectAsState()
    val isLoggedIn by authViewModel
        .isLoggedIn.collectAsState()

    var emailOrUsername by remember {
        mutableStateOf("") }
    var password by remember {
        mutableStateOf("") }
    var passwordVisible by remember {
        mutableStateOf(false) }

    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn) {
            navController.navigate(
                Screen.Main.route) {
                popUpTo(Screen.Welcome.route) {
                    inclusive = true
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF120810))
            .padding(
                horizontal = 24.dp,
                vertical = 52.dp
            ),
        verticalArrangement =
            Arrangement.spacedBy(20.dp)
    ) {
        Row(verticalAlignment =
            Alignment.CenterVertically) {
            IconButton(onClick = {
                navController.popBackStack()
            }) {
                Icon(
                    Icons.Default.ArrowBackIos,
                    contentDescription = "Geri",
                    tint = Color(0xFF8A6070),
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = "Giriş Yap",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFC8A8B4)
            )
        }

        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF8A3055),
                            Color(0xFF6B2040)
                        )
                    )
                )
                .align(Alignment.CenterHorizontally),
            contentAlignment = Alignment.Center
        ) {
            Text("🌙", fontSize = 36.sp)
        }

        AuthTextField(
            value = emailOrUsername,
            onValueChange = {
                emailOrUsername = it },
            label = "E-posta veya Kullanıcı Adı",
            placeholder =
                "ornek@email.com veya kullanici"
        )

        AuthTextField(
            value = password,
            onValueChange = { password = it },
            label = "Şifre",
            placeholder = "Şifrenizi girin",
            isPassword = true,
            passwordVisible = passwordVisible,
            onPasswordToggle = {
                passwordVisible = !passwordVisible
            }
        )

        Text(
            text = "Şifremi Unuttum",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF8A3055),
            modifier = Modifier
                .align(Alignment.End)
                .clickable {
                    if (emailOrUsername
                            .contains("@")) {
                        authViewModel
                            .sendPasswordReset(
                                emailOrUsername)
                    }
                }
        )

        if (errorMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Color(0xFF6B2040)
                            .copy(alpha = 0.2f))
                    .padding(12.dp)
            ) {
                Text(
                    text = "⚠️ $errorMessage",
                    fontSize = 13.sp,
                    color = Color(0xFFE8A0A0)
                )
            }
        }

        Button(
            onClick = {
                authViewModel.login(
                    emailOrUsername =
                        emailOrUsername,
                    password = password
                )
            },
            enabled = !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF6B2040)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    color = Color(0xFFF0D0DC),
                    modifier = Modifier.size(24.dp)
                )
            } else {
                Text(
                    text = "Giriş Yap",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFF0D0DC)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement =
                Arrangement.Center
        ) {
            Text(
                text = "Hesabın yok mu? ",
                fontSize = 13.sp,
                color = Color(0xFF5A3848)
            )
            Text(
                text = "Hesap Oluştur",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF8A3055),
                modifier = Modifier.clickable {
                    navController.navigate(
                        Screen.Register.route)
                }
            )
        }
    }
}
