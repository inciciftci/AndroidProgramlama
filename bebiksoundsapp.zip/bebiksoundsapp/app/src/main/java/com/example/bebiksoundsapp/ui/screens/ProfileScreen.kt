package com.example.bebiksoundsapp.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIos
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.bebiksoundsapp.ui.Screen
import com.example.bebiksoundsapp.viewmodel.ProfileViewModel
import kotlinx.coroutines.delay

@Composable
fun ProfileScreen(navController: NavController) {
    val viewModel: ProfileViewModel = viewModel()
    val profile by viewModel
        .currentProfile.collectAsState()
    val isLoading by viewModel
        .isLoading.collectAsState()
    val errorMessage by viewModel
        .errorMessage.collectAsState()
    val successMessage by viewModel
        .successMessage.collectAsState()
    val context = LocalContext.current

    // Fotoğraf seçici
    val photoPicker =
        rememberLauncherForActivityResult(
            ActivityResultContracts
                .PickVisualMedia()
        ) { uri ->
            uri?.let {
                viewModel.updateProfilePhoto(
                    it, context)
            }
        }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF120810))
            .verticalScroll(rememberScrollState())
            .padding(
                top = 52.dp,
                start = 22.dp,
                end = 22.dp,
                bottom = 32.dp
            )
    ) {
        // Geri butonu + başlık
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 28.dp),
            verticalAlignment =
                Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1C1018))
                    .clickable {
                        navController.popBackStack()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector =
                        Icons.Default.ArrowBackIos,
                    contentDescription = "Geri",
                    tint = Color(0xFF8A6070),
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Text(
                text = "Profilim",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFC8A8B4)
            )
        }

        // Profil fotoğrafı
        Box(
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF261820))
                    .border(
                        2.dp,
                        Color(0xFF6B2040),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (profile?.profilePhotoUrl
                        ?.isNotEmpty() == true) {
                    AsyncImage(
                        model = profile
                            ?.profilePhotoUrl,
                        contentDescription =
                            "Profil fotoğrafı",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape),
                        contentScale =
                            ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector =
                            Icons.Default.Person,
                        contentDescription = null,
                        tint = Color(0xFF8A3055),
                        modifier = Modifier.size(48.dp)
                    )
                }
            }

            // Fotoğraf değiştir butonu
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF6B2040))
                    .align(Alignment.BottomEnd)
                    .clickable {
                        photoPicker.launch(
                            PickVisualMediaRequest(
                                ActivityResultContracts
                                    .PickVisualMedia
                                    .ImageOnly
                            )
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector =
                        Icons.Default.CameraAlt,
                    contentDescription =
                        "Fotoğraf değiştir",
                    tint = Color(0xFFF0D0DC),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Kullanıcı bilgileri kartı
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF1C1018))
                .padding(18.dp),
            verticalArrangement =
                Arrangement.spacedBy(14.dp)
        ) {
            ProfileInfoRow(
                icon = "👤",
                label = "Ad Soyad",
                value = profile?.displayName ?: "—"
            )
            Divider(color = Color(0xFF261820))
            ProfileInfoRow(
                icon = "@",
                label = "Kullanıcı Adı",
                value = "@${profile?.username ?: "—"}"
            )
            Divider(color = Color(0xFF261820))
            ProfileInfoRow(
                icon = "✉️",
                label = "E-posta",
                value = profile?.email ?: "—"
            )
        }

        Spacer(Modifier.height(16.dp))

        // Şifre sıfırla butonu
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF1C1018))
                .border(
                    1.dp,
                    Color(0xFF261820),
                    RoundedCornerShape(16.dp)
                )
                .clickable {
                    viewModel.sendPasswordReset()
                }
                .padding(18.dp)
        ) {
            Row(
                verticalAlignment =
                    Alignment.CenterVertically,
                horizontalArrangement =
                    Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Color(0xFF8A3055),
                    modifier = Modifier.size(20.dp)
                )
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "Şifremi Sıfırla",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFC8A8B4)
                    )
                    Text(
                        text = "E-postana sıfırlama " +
                            "bağlantısı gönderilir",
                        fontSize = 11.sp,
                        color = Color(0xFF8A6070)
                    )
                }
                Icon(
                    imageVector =
                        Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = Color(0xFF5A3848)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        // Çıkış yap butonu
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Color(0xFF6B2040)
                        .copy(alpha = 0.15f)
                )
                .border(
                    1.dp,
                    Color(0xFF6B2040)
                        .copy(alpha = 0.3f),
                    RoundedCornerShape(16.dp)
                )
                .clickable {
                    viewModel.logout {
                        navController.navigate(
                            Screen.Welcome.route
                        ) {
                            popUpTo(0) {
                                inclusive = true
                            }
                        }
                    }
                }
                .padding(18.dp)
        ) {
            Row(
                verticalAlignment =
                    Alignment.CenterVertically,
                horizontalArrangement =
                    Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Logout,
                    contentDescription = null,
                    tint = Color(0xFF8A3055),
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "Çıkış Yap",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFC8A8B4),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Yükleniyor
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = Color(0xFF8A3055),
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Hata mesajı
        if (errorMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Color(0xFF6B2040)
                            .copy(alpha = 0.2f))
                    .padding(12.dp)
            ) {
                Text(
                    text = "⚠️ $errorMessage",
                    fontSize = 13.sp,
                    color = Color(0xFFE8A0A0)
                )
            }
            LaunchedEffect(errorMessage) {
                delay(3000)
                viewModel.clearMessages()
            }
        }

        // Başarı mesajı
        if (successMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Color(0xFF1A2A20))
                    .padding(12.dp)
            ) {
                Text(
                    text = "✓ $successMessage",
                    fontSize = 13.sp,
                    color = Color(0xFF4A9068)
                )
            }
            LaunchedEffect(successMessage) {
                delay(3000)
                viewModel.clearMessages()
            }
        }
    }
}

// Yardımcı Composable
@Composable
fun ProfileInfoRow(
    icon: String,
    label: String,
    value: String
) {
    Row(
        verticalAlignment =
            Alignment.CenterVertically,
        horizontalArrangement =
            Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = icon,
            fontSize = 18.sp,
            modifier = Modifier.width(24.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                fontSize = 11.sp,
                color = Color(0xFF8A6070)
            )
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFC8A8B4)
            )
        }
    }
}
