package com.example.bebiksoundsapp.ui

sealed class Screen(val route: String) {
    object Welcome : Screen("welcome")
    object Login : Screen("login")
    object Register : Screen("register")
    object Main : Screen("main")
    object SoundList : Screen("sound_list")
    object Player : Screen("player")
    object Child : Screen("child")
    object Analysis : Screen("analysis")
    object Profile : Screen("profile")
}
