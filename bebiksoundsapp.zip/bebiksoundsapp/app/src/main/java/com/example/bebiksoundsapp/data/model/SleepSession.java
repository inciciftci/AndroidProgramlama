package com.example.bebiksoundsapp.data.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "sleep_sessions")
public class SleepSession {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String date;
    private String time;
    private String category;
    private String songName;
    private int playDuration;
    private boolean babySlept;
    private int minutesToSleep;
    private int timerSet;

    public SleepSession() {
    }

    public SleepSession(int id, String date, String time, String category, String songName, int playDuration,
                        boolean babySlept, int minutesToSleep, int timerSet) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.category = category;
        this.songName = songName;
        this.playDuration = playDuration;
        this.babySlept = babySlept;
        this.minutesToSleep = minutesToSleep;
        this.timerSet = timerSet;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public int getPlayDuration() {
        return playDuration;
    }

    public void setPlayDuration(int playDuration) {
        this.playDuration = playDuration;
    }

    public boolean isBabySlept() {
        return babySlept;
    }

    public void setBabySlept(boolean babySlept) {
        this.babySlept = babySlept;
    }

    public int getMinutesToSleep() {
        return minutesToSleep;
    }

    public void setMinutesToSleep(int minutesToSleep) {
        this.minutesToSleep = minutesToSleep;
    }

    public int getTimerSet() {
        return timerSet;
    }

    public void setTimerSet(int timerSet) {
        this.timerSet = timerSet;
    }
}
