package com.example.bebiksoundsapp.ui

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.bebiksoundsapp.analysis.SleepAnalyzer
import com.example.bebiksoundsapp.data.model.SleepSession
import com.example.bebiksoundsapp.data.repository.SleepRepository
import com.example.bebiksoundsapp.model.SoundCategory
import com.example.bebiksoundsapp.model.soundCategories
import java.time.LocalDate
import java.time.LocalTime
import java.time.temporal.ChronoUnit
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SoundViewModel(application: Application) : AndroidViewModel(application) {
    private val sleepRepository =
        SleepRepository(application)
    private var sessionStartTime: LocalTime? = null
    private var sessionStartDate: LocalDate? = null

    val selectedCategory = MutableStateFlow<SoundCategory?>(null)
    val playingItem = MutableStateFlow<SoundItem?>(null)
    val appMode = MutableStateFlow<AppMode>(AppMode.PARENT)
    val favoriteItems = MutableStateFlow<List<SoundItem>>(emptyList())
    private var lastModeSwitchAtMs: Long = 0L

    val isFavorite: StateFlow<Boolean> = combine(
        playingItem, favoriteItems
    ) { playing, favs ->
        favs.any { it.id == playing?.id }
    }.stateIn(viewModelScope, SharingStarted.Lazily, false)

    private val _selectedSound = MutableStateFlow(soundCategories[0])
    val selectedSound: StateFlow<SoundCategory> = _selectedSound.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _progress = MutableStateFlow(0.32f)
    val progress: StateFlow<Float> = _progress.asStateFlow()

    private val _timerMinutes = MutableStateFlow(30)
    val timerMinutes: StateFlow<Int> = _timerMinutes.asStateFlow()
    private val _timerRemainingSeconds = MutableStateFlow(30 * 60)
    val timerRemainingSeconds: StateFlow<Int> = _timerRemainingSeconds.asStateFlow()

    private val _confirmedMinutes = MutableStateFlow(30)
    val confirmedMinutes: StateFlow<Int> = _confirmedMinutes.asStateFlow()

    private val _isTimerPending = MutableStateFlow(false)
    val isTimerPending: StateFlow<Boolean> = _isTimerPending.asStateFlow()

    private val _isTimerConfirmed = MutableStateFlow(false)
    val isTimerConfirmed: StateFlow<Boolean> = _isTimerConfirmed.asStateFlow()

    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private val _isTimerPaused = MutableStateFlow(false)
    val isTimerPaused: StateFlow<Boolean> = _isTimerPaused.asStateFlow()

    private var remainingSeconds: Int = _timerMinutes.value * 60

    val isPlayTimeUp = MutableStateFlow(false)
    val showSleepDialog = MutableStateFlow(false)
    val sleepSuggestion = MutableStateFlow<String?>(null)
    val sessionCount = MutableStateFlow(0)
    private var timerJob: Job? = null

    val isTimerEnabled = MutableStateFlow(false)

    fun onPlayTimeUp() {
        isPlayTimeUp.value = true
        showSleepDialog.value = true
    }

    fun selectSound(category: SoundCategory) {
        _selectedSound.value = category
    }

    fun togglePlay() {
        val wasPlaying = isPlaying.value
        _isPlaying.value = !_isPlaying.value

        if (!wasPlaying && isPlaying.value) {
            // Ses çalmaya başladı — oturum başlat
            startSession()
        }
    }

    fun startSession() {
        sessionStartTime = LocalTime.now()
        sessionStartDate = LocalDate.now()
    }

    fun saveSession(
        babySlept: Boolean,
        minutesToSleep: Int
    ) {
        val start = sessionStartTime ?: return
        val date = sessionStartDate ?: return
        val now = LocalTime.now()
        val duration = ChronoUnit.MINUTES
            .between(start, now).toInt()

        val session = SleepSession()
        session.date = date.toString()
        session.time = start.toString()
            .substring(0, 5)
        session.category =
            selectedCategory.value?.name ?: ""
        session.songName =
            playingItem.value?.name ?: ""
        session.playDuration = duration
        session.isBabySlept = babySlept
        session.minutesToSleep = minutesToSleep
        session.timerSet =
            confirmedMinutes.value

        viewModelScope.launch(Dispatchers.IO) {
            sleepRepository.insertSession(session)
        }
    }

    fun loadAnalysis() {
        viewModelScope.launch(Dispatchers.IO) {
            val sessions = sleepRepository.getAllSessions()
            val count = sleepRepository.getSessionCount()
            val suggestion = SleepAnalyzer
                .generateSuggestion(sessions)

            sessionCount.value = count
            sleepSuggestion.value = suggestion
        }
    }

    fun adjustTimer(delta: Int) {
        if (_isTimerRunning.value) return
        _timerMinutes.value = (_timerMinutes.value + delta).coerceIn(5, 120)
        remainingSeconds = _timerMinutes.value * 60
        _timerRemainingSeconds.value = remainingSeconds
        _isTimerPending.value = _timerMinutes.value != _confirmedMinutes.value
        _isTimerConfirmed.value = false
        _isTimerPaused.value = false
    }

    fun confirmTimer() {
        timerJob?.cancel()
        _confirmedMinutes.value = _timerMinutes.value
        remainingSeconds = _confirmedMinutes.value * 60
        _timerRemainingSeconds.value = remainingSeconds
        _isTimerPending.value = false
        _isTimerConfirmed.value = true
        _isTimerRunning.value = true
        _isTimerPaused.value = false
        isTimerEnabled.value = true
        startTimerCountdown()
    }

    private fun startTimerCountdown() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            var remainingSeconds = 10
            // Normalde: timerMinutes.value * 60
            while (remainingSeconds > 0) {
                delay(1000L)
                remainingSeconds--
                _timerMinutes.value =
                    remainingSeconds / 60
            }
            // Süre doldu — sırayla bunları yap:
            _isPlaying.value = false
            showSleepDialog.value = true
        }
    }

    fun pauseTimer() {
        if (!_isTimerRunning.value) return
        timerJob?.cancel()
        _isTimerRunning.value = false
        _isTimerPaused.value = true
    }

    fun resumeTimer() {
        if (!_isTimerPaused.value || remainingSeconds <= 0) return
        _isTimerRunning.value = true
        _isTimerPaused.value = false
        _isTimerConfirmed.value = true
        isTimerEnabled.value = true
        startTimerCountdown()
    }

    fun resetTimer() {
        timerJob?.cancel()
        remainingSeconds = _confirmedMinutes.value * 60
        _timerMinutes.value = _confirmedMinutes.value
        _timerRemainingSeconds.value = remainingSeconds
        _isTimerRunning.value = false
        _isTimerPaused.value = false
        _isTimerConfirmed.value = false
        _isTimerPending.value = false
        isTimerEnabled.value = false
        isPlayTimeUp.value = false
    }

    fun toggleTimer() {
        isTimerEnabled.value = !isTimerEnabled.value
        if (!isTimerEnabled.value) {
            timerJob?.cancel()
            _isTimerRunning.value = false
            _isTimerPaused.value = false
        }
    }

    fun openCategory(category: SoundCategory) {
        selectedCategory.value = category
        if (category.type == CategoryType.SOUND_LIST) {
            playingItem.value = category.items.firstOrNull()
        }
    }

    fun selectItem(item: SoundItem) {
        playingItem.value = item
    }

    fun toggleAppMode() {
        val now = SystemClock.elapsedRealtime()
        // Hızlı art arda tıklamalarda state/navigation üst üste binmesin.
        if (now - lastModeSwitchAtMs < 450L) return
        lastModeSwitchAtMs = now

        appMode.value =
            if (appMode.value == AppMode.PARENT) AppMode.CHILD else AppMode.PARENT
    }

    fun setAppMode(mode: AppMode) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastModeSwitchAtMs < 450L) return
        lastModeSwitchAtMs = now
        if (appMode.value == mode) return
        appMode.value = mode
    }

    fun toggleFavorite(item: SoundItem?) {
        item ?: return
        val current = favoriteItems.value.toMutableList()
        if (current.any { it.id == item.id }) {
            current.removeAll { it.id == item.id }
        } else {
            current.add(item)
        }
        favoriteItems.value = current
    }

    fun playNext() {
        val items = getActiveItems()
        if (items.isEmpty()) return
        
        val currentIndex = items.indexOfFirst { it.id == playingItem.value?.id }
        val nextIndex = if (currentIndex == -1 || currentIndex == items.size - 1) 0 else currentIndex + 1
        playingItem.value = items[nextIndex]
    }

    fun playPrevious() {
        val items = getActiveItems()
        if (items.isEmpty()) return
        
        val currentIndex = items.indexOfFirst { it.id == playingItem.value?.id }
        val prevIndex = if (currentIndex <= 0) items.size - 1 else currentIndex - 1
        playingItem.value = items[prevIndex]
    }

    private fun getActiveItems(): List<SoundItem> {
        val category = selectedCategory.value ?: return emptyList()
        return if (category.type == CategoryType.FAVORITES) {
            favoriteItems.value
        } else {
            category.items
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        showSleepDialog.value = true
    }
}

data class SoundItem(
    val id: Int, 
    val name: String, 
    val audioResId: Int,
    val duration: String = "03:45"
)
enum class AppMode { PARENT, CHILD }
enum class CategoryType { HOME, SOUND_LIST, FAVORITES, SLEEP_TIPS }
