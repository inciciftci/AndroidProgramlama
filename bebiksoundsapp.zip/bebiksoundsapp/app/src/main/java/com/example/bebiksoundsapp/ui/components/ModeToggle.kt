package com.example.bebiksoundsapp.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bebiksoundsapp.ui.theme.*

@Composable
fun ModeToggle(
    isChildMode: Boolean,
    onToggle: () -> Unit,
    trackActiveColor: Color = Color(0xFF3A1228),
    trackActiveBorder: Color = Color(0xFF6B2040),
    thumbActiveColor: Color = Color(0xFF8A3055),
    thumbIconTint: Color = Color(0xFFF0D0DC),
    labelColor: Color = Color(0xFF8A3055),
    labelInactiveColor: Color = Color(0xFF5A3848)
) {
    val thumbOffset by animateDpAsState(
        targetValue = if (isChildMode) 26.dp else 3.dp,
        animationSpec = tween(250)
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(
            modifier = Modifier
                .width(56.dp)
                .height(30.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(
                    if (isChildMode) trackActiveColor else Surface2
                )
                .border(
                    1.5.dp,
                    if (isChildMode) trackActiveBorder else AccentDim,
                    RoundedCornerShape(15.dp)
                )
                .clickable { onToggle() }
        ) {
            Box(
                modifier = Modifier
                    .padding(top = 3.dp)
                    .offset(x = thumbOffset)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(
                        if (isChildMode) thumbActiveColor else Surface1
                    )
                    .shadow(4.dp, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isChildMode)
                        Icons.Default.ChildCare
                    else
                        Icons.Default.People,
                    contentDescription = null,
                    tint = if (isChildMode)
                        thumbIconTint
                    else TextHigh,
                    modifier = Modifier.size(13.dp)
                )
            }
        }
        Text(
            text = if (isChildMode) "Çocuk" else "Ebeveyn",
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = if (isChildMode) labelColor else labelInactiveColor
        )
    }
}
