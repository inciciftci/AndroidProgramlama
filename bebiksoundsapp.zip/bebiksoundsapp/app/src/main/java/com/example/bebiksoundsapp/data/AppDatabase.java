package com.example.bebiksoundsapp.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.bebiksoundsapp.data.dao.SleepSessionDao;
import com.example.bebiksoundsapp.data.model.SleepSession;

@Database(
        entities = {
                SleepSession.class
        },
        version = 3,
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static final String DB_NAME = "bebik_sounds_db";
    private static volatile AppDatabase INSTANCE;

    static final Migration MIGRATION_1_2 =
            new Migration(1, 2) {
                @Override
                public void migrate(SupportSQLiteDatabase database) {
                    database.execSQL(
                            "CREATE TABLE IF NOT EXISTS " +
                                    "sleep_sessions (" +
                                    "id INTEGER PRIMARY KEY " +
                                    "AUTOINCREMENT NOT NULL, " +
                                    "date TEXT, " +
                                    "time TEXT, " +
                                    "category TEXT, " +
                                    "songName TEXT, " +
                                    "playDuration INTEGER NOT NULL, " +
                                    "babySlept INTEGER NOT NULL, " +
                                    "minutesToSleep INTEGER NOT NULL, " +
                                    "timerSet INTEGER NOT NULL)"
                    );
                }
            };

    public abstract SleepSessionDao sleepSessionDao();

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    DB_NAME
                            )
                            .addMigrations(MIGRATION_1_2)
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
