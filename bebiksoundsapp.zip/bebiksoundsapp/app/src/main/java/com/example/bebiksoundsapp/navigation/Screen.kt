package com.example.bebiksoundsapp.navigation

sealed class Screen(val route: String) {
    object Main : Screen("main")
    object SoundList : Screen("sound_list")
    object Player : Screen("player")
    object Child : Screen("child")
}
