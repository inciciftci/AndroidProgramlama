package com.example.bebiksoundsapp.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.bebiksoundsapp.data.model.UserProfile
import com.example.bebiksoundsapp.di.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.filter.FilterOperation
import io.github.jan.supabase.storage.storage

class AuthRepository {

    private val client = SupabaseClient.client
    private val auth = client.auth
    private val db = client.postgrest
    private val storage = client.storage

    val isLoggedIn: Boolean
        get() = auth.currentUserOrNull() != null

    suspend fun register(
        email: String,
        password: String,
        displayName: String,
        username: String,
        photoUri: Uri?,
        context: Context
    ): Result<UserProfile> {
        return try {
            // 1. Username kontrolü
            val existing = db["profiles"]
                .select {
                    filter {
                        eq("username", username)
                    }
                }.decodeSingleOrNull<UserProfile>()

            if (existing != null) {
                return Result.failure(
                    Exception(
                        "Bu kullanıcı adı " +
                        "zaten alınmış"))
            }

            // 2. Auth ile kayıt ol
            auth.signUpWith(Email) {
                this.email = email
                this.password = password
            }

            val uid = auth.currentUserOrNull()?.id
                ?: auth.currentSessionOrNull()?.user?.id
                ?: throw Exception(
                    "Kayit olusturma tamamlandi ancak oturum acilmadi. Supabase Auth ayarinda email dogrulamasi acik olabilir. E-postani dogrulayıp tekrar giris yap."
                )

            // 3. Profil fotoğrafı yükle
            var photoUrl = ""
            if (photoUri != null) {
                try {
                    val bytes = context
                        .contentResolver
                        .openInputStream(photoUri)
                        ?.readBytes()
                    if (bytes != null) {
                        storage["profiles"]
                            .upload(
                                "$uid/photo.jpg",
                                bytes,
                                upsert = true
                            )
                        photoUrl = storage["profiles"]
                            .publicUrl("$uid/photo.jpg")
                    }
                } catch (photoError: Exception) {
                    Log.w(
                        "AuthRepository",
                        "Profil fotografi yuklenemedi, kayit fotosuz devam edecek: ${photoError.message}"
                    )
                }
            }

            // 4. Profili kaydet
            val profile = UserProfile(
                id = uid,
                email = email,
                displayName = displayName,
                username = username,
                profilePhotoUrl = photoUrl
            )

            db["profiles"].insert(profile)

            Result.success(profile)

        } catch (e: Exception) {
            Log.e("AuthRepository",
                "Kayıt hatası: ${e.message}", e)
            Result.failure(
                Exception(
                    mapError(e.message)))
        }
    }

    suspend fun login(
        emailOrUsername: String,
        password: String
    ): Result<UserProfile> {
        return try {
            // Username ile giriş — email bul
            val loginEmail = if (emailOrUsername
                    .contains("@")) {
                emailOrUsername
            } else {
                val profile = db["profiles"]
                    .select {
                        filter {
                            eq("username",
                                emailOrUsername)
                        }
                    }
                    .decodeSingleOrNull<UserProfile>()
                    ?: throw Exception(
                        "Kullanıcı bulunamadı")
                profile.email
            }

            auth.signInWith(Email) {
                this.email = loginEmail
                this.password = password
            }

            val uid = auth.currentUserOrNull()
                ?.id
                ?: throw Exception(
                    "Giriş başarısız")

            val profile = db["profiles"]
                .select {
                    filter { eq("id", uid) }
                }
                .decodeSingleOrNull<UserProfile>()
                ?: createMissingProfile(
                    uid = uid,
                    email = auth.currentUserOrNull()?.email
                        ?: loginEmail
                )

            Result.success(profile)

        } catch (e: Exception) {
            Log.e("AuthRepository",
                "Giriş hatası: ${e.message}", e)
            Result.failure(
                Exception(
                    mapError(e.message)))
        }
    }

    fun logout() {
        // coroutine içinde çağır
    }

    suspend fun logoutSuspend() {
        try {
            auth.signOut()
        } catch (e: Exception) {
            Log.e("AuthRepository",
                "Çıkış hatası: ${e.message}")
        }
    }

    suspend fun sendPasswordReset(
        email: String
    ): Result<Unit> {
        return try {
            auth.resetPasswordForEmail(email)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUserProfile():
        Result<UserProfile> {
        return try {
            val uid = auth.currentUserOrNull()
                ?.id
                ?: return Result.failure(
                    Exception("Giriş yapılmamış"))
            val profile = db["profiles"]
                .select {
                    filter { eq("id", uid) }
                }
                .decodeSingle<UserProfile>()
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun createMissingProfile(
        uid: String,
        email: String
    ): UserProfile {
        val baseUsername = email
            .substringBefore("@")
            .ifBlank { "user" }
            .lowercase()
            .replace(Regex("[^a-z0-9_.]"), "")
            .ifBlank { "user" }

        val profile = UserProfile(
            id = uid,
            email = email,
            displayName = email.substringBefore("@"),
            username = "${baseUsername}_${uid.take(6)}",
            profilePhotoUrl = ""
        )

        db["profiles"].insert(profile)
        return profile
    }

    private fun mapError(
        message: String?
    ): String {
        return when {
            message == null ->
                "Bilinmeyen hata"
            message.contains(
                "already registered") ->
                "Bu e-posta zaten kullanımda"
            message.contains(
                "Invalid login") ->
                "E-posta veya şifre hatalı"
            message.contains(
                "Email not confirmed") ->
                "E-postanızı doğrulayın"
            message.contains("senin-proje-id") ||
                message.contains("senin-anon-key") ||
                message.contains("Supabase ayari eksik") ->
                "Supabase baglantisi hazir degil. local.properties dosyasinda SUPABASE_URL ve SUPABASE_ANON_KEY degerlerini kendi Supabase projenle degistir."
            message.contains(
                "network") ->
                "İnternet bağlantısı yok"
            else -> message
        }
    }
}
