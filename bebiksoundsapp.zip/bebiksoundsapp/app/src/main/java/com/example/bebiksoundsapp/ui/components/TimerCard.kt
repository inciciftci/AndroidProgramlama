package com.example.bebiksoundsapp.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bebiksoundsapp.ui.theme.*

@Composable
fun TimerCard(
    timerMinutes: Int,
    timerRemainingSeconds: Int,
    isTimerPending: Boolean,
    isTimerConfirmed: Boolean,
    isTimerRunning: Boolean,
    isTimerPaused: Boolean,
    onAdjust: (Int) -> Unit,
    onConfirm: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onReset: () -> Unit
) {
    val displayMinutes = timerRemainingSeconds / 60
    val displaySeconds = timerRemainingSeconds % 60
    val displayTime = String.format("%02d:%02d", displayMinutes, displaySeconds)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(color = Surface1, shape = RoundedCornerShape(26.dp))
            .padding(24.dp)
    ) {
        // Üst Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sol — 48x48dp Box
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(color = AccentDim, shape = RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "⏱", fontSize = 24.sp)
            }
            
            Spacer(modifier = Modifier.width(18.dp))
            
            // Orta (weight=1f) — Column
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "OTOMATİK KAPANMA",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.8.sp,
                    color = TextLow
                )
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = displayTime,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextHigh
                    )
                    Text(
                        text = " dk:sn",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextLow,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
            }
            
            // Sağ — Row gap 8dp
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Eksi butonu
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(color = AccentDim, shape = RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onAdjust(-5) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "−", fontSize = 22.sp, color = Color(0xFFA87088))
                }
                // Artı butonu
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(color = Accent, shape = RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onAdjust(5) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "+", fontSize = 22.sp, color = TextHigh)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider(color = Surface2, thickness = 1.dp)
        Spacer(modifier = Modifier.height(16.dp))
        
        // Alt Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Sol — Row gap 8dp
            Row(verticalAlignment = Alignment.CenterVertically) {
                val statusText = when {
                    isTimerRunning -> "$displayTime kaldı"
                    isTimerPaused -> "$displayTime (durduruldu)"
                    isTimerPending -> "${timerMinutes}:00 seçildi"
                    else -> "Süre ayarlanmadı"
                }

                val statusColor = when {
                    isTimerRunning || isTimerPaused || isTimerPending -> AmberColor
                    else -> TextLow
                }

                if (isTimerRunning || isTimerPaused || isTimerPending) {
                    Box(modifier = Modifier.size(8.dp).background(AmberColor, CircleShape))
                    Spacer(modifier = Modifier.width(8.dp))
                }

                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            
            // Sağ — "Onayla" butonu
            val isEnabled = isTimerPending || isTimerPaused
            val confirmBg = if (isTimerConfirmed) Color(0xFF0C2018) else Accent
            val confirmTextColor = if (isTimerConfirmed) Color(0xFF4A9068) else TextHigh
            val confirmText = if (isTimerConfirmed) "✓ Onaylandı" else "Onayla"

            Box(
                modifier = Modifier
                    .alpha(if (isTimerPending || isTimerConfirmed) 1f else 0.35f)
                    .background(color = confirmBg, shape = RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(enabled = isEnabled) { onConfirm() }
                    .padding(vertical = 11.dp, horizontal = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = confirmText,
                    color = confirmTextColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (isTimerRunning || isTimerPaused) {
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val actionText = if (isTimerRunning) "Durdur" else "Devam Et"
                val actionClick = if (isTimerRunning) onPause else onResume
                val actionBg = if (isTimerRunning) Color(0xFF2C1A06) else Color(0xFF1C2A14)
                val actionTextColor = if (isTimerRunning) Color(0xFFF3B56C) else Color(0xFF89D46A)

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(color = actionBg, shape = RoundedCornerShape(14.dp))
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { actionClick() }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = actionText,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = actionTextColor
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(color = Surface2, shape = RoundedCornerShape(14.dp))
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onReset() }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Yeniden Ayarla",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextHigh
                    )
                }
            }
        }
    }
}
