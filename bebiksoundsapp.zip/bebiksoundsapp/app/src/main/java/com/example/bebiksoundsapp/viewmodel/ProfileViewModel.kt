package com.example.bebiksoundsapp.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.bebiksoundsapp.data.model.UserProfile
import com.example.bebiksoundsapp.data.repository.AuthRepository
import com.example.bebiksoundsapp.di.SupabaseClient
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class ProfileViewModel(application: Application)
    : AndroidViewModel(application) {

    private val authRepository = AuthRepository()
    private val supabase = SupabaseClient.client

    val isLoading = MutableStateFlow(false)
    val errorMessage = MutableStateFlow<String?>(null)
    val successMessage = MutableStateFlow<String?>(null)
    val currentProfile =
        MutableStateFlow<UserProfile?>(null)

    init {
        loadProfile()
    }

    fun loadProfile() {
        viewModelScope.launch {
            isLoading.value = true
            authRepository.getUserProfile()
                .onSuccess { profile ->
                    currentProfile.value = profile
                }
                .onFailure { e ->
                    errorMessage.value = e.message
                }
            isLoading.value = false
        }
    }

    fun updateProfilePhoto(
        photoUri: Uri,
        context: Context
    ) {
        viewModelScope.launch {
            isLoading.value = true
            errorMessage.value = null
            try {
                val uid = supabase.auth
                    .currentUserOrNull()?.id
                    ?: throw Exception(
                        "Giriş yapılmamış")

                val bytes = context
                    .contentResolver
                    .openInputStream(photoUri)
                    ?.readBytes()
                    ?: throw Exception(
                        "Fotoğraf okunamadı")

                // Storage'a yükle
                supabase.storage["profiles"]
                    .upload(
                        "$uid/photo.jpg",
                        bytes,
                        upsert = true
                    )

                val photoUrl = supabase
                    .storage["profiles"]
                    .publicUrl("$uid/photo.jpg")

                // Profili güncelle
                supabase.postgrest["profiles"]
                    .update({
                        set("profile_photo_url",
                            photoUrl)
                    }) {
                        filter {
                            eq("id", uid)
                        }
                    }

                currentProfile.value =
                    currentProfile.value
                        ?.copy(
                            profilePhotoUrl =
                                photoUrl)

                successMessage.value =
                    "Profil fotoğrafı güncellendi"

            } catch (e: Exception) {
                errorMessage.value = e.message
            }
            isLoading.value = false
        }
    }

    fun sendPasswordReset() {
        viewModelScope.launch {
            val email = currentProfile
                .value?.email ?: return@launch
            authRepository
                .sendPasswordReset(email)
                .onSuccess {
                    successMessage.value =
                        "Şifre sıfırlama e-postası " +
                            "gönderildi"
                }
                .onFailure { e ->
                    errorMessage.value = e.message
                }
        }
    }

    fun logout(onLogout: () -> Unit) {
        viewModelScope.launch {
            authRepository.logoutSuspend()
            onLogout()
        }
    }

    fun clearMessages() {
        errorMessage.value = null
        successMessage.value = null
    }
}
