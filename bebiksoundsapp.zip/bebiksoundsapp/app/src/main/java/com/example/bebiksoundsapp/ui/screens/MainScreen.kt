package com.example.bebiksoundsapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.bebiksoundsapp.model.soundCategories
import com.example.bebiksoundsapp.ui.AppMode
import com.example.bebiksoundsapp.ui.Screen
import com.example.bebiksoundsapp.ui.SoundViewModel
import com.example.bebiksoundsapp.ui.components.ModeToggle
import com.example.bebiksoundsapp.ui.components.NowPlayingCard
import com.example.bebiksoundsapp.ui.components.SoundGrid
import com.example.bebiksoundsapp.ui.components.TimerCard
import com.example.bebiksoundsapp.ui.theme.BgColor
import com.example.bebiksoundsapp.ui.theme.TextHigh
import com.example.bebiksoundsapp.ui.theme.TextLow
import com.example.bebiksoundsapp.ui.theme.TextMid

@Composable
fun MainScreen(navController: NavController, viewModel: SoundViewModel) {
    val selectedSound by viewModel.selectedSound.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val timerMinutes by viewModel.timerMinutes.collectAsState()
    val timerRemainingSeconds by viewModel.timerRemainingSeconds.collectAsState()
    val isTimerPending by viewModel.isTimerPending.collectAsState()
    val isTimerConfirmed by viewModel.isTimerConfirmed.collectAsState()
    val isTimerRunning by viewModel.isTimerRunning.collectAsState()
    val isTimerPaused by viewModel.isTimerPaused.collectAsState()
    val playingItem by viewModel.playingItem.collectAsState()
    val appMode by viewModel.appMode.collectAsState()
    val showSleepDialog by
        viewModel.showSleepDialog.collectAsState()
    var minutesToSleep by remember {
        mutableStateOf(15)
    }

    if (showSleepDialog) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = Color(0xFF1C1018),
            shape = RoundedCornerShape(24.dp),
            title = {
                Column(
                    horizontalAlignment =
                        Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("🌙", fontSize = 40.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Bebeğiniz uyudu mu?",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFC8A8B4),
                        textAlign = TextAlign.Center
                    )
                }
            },
            text = {
                Column(
                    horizontalAlignment =
                        Alignment.CenterHorizontally,
                    verticalArrangement =
                        Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "Kaç dakikada uyudu?",
                        fontSize = 13.sp,
                        color = Color(0xFF8A6070)
                    )
                    Row(
                        verticalAlignment =
                            Alignment.CenterVertically,
                        horizontalArrangement =
                            Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    Color(0xFF3A1228))
                                .clickable {
                                    if (minutesToSleep > 5)
                                        minutesToSleep -= 5
                                },
                            contentAlignment =
                                Alignment.Center
                        ) {
                            Text(
                                "−",
                                fontSize = 20.sp,
                                color = Color(0xFFA87088)
                            )
                        }
                        Column(
                            horizontalAlignment =
                                Alignment.CenterHorizontally
                        ) {
                            Text(
                                "$minutesToSleep",
                                fontSize = 32.sp,
                                fontWeight =
                                    FontWeight.ExtraBold,
                                color = Color(0xFFC8A8B4)
                            )
                            Text(
                                "dakika",
                                fontSize = 11.sp,
                                color = Color(0xFF8A6070)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    Color(0xFF6B2040))
                                .clickable {
                                    minutesToSleep += 5
                                },
                            contentAlignment =
                                Alignment.Center
                        ) {
                            Text(
                                "+",
                                fontSize = 20.sp,
                                color = Color(0xFFF0D0DC)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveSession(
                            babySlept = true,
                            minutesToSleep = minutesToSleep
                        )
                        viewModel.showSleepDialog
                            .value = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF6B2040)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        "✓ Uyudu",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFF0D0DC)
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        viewModel.saveSession(
                            babySlept = false,
                            minutesToSleep = 0
                        )
                        viewModel.showSleepDialog
                            .value = false
                    },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        1.5.dp, Color(0xFF6B2040))
                ) {
                    Text(
                        "Uymadı",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF8A6070)
                    )
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 26.dp)
            .padding(top = 54.dp, bottom = 30.dp)
    ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 26.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "UYKU MODU",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.5.sp,
                        color = TextLow
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Bebeğiniz için\nrahatlatıcı sesler",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextHigh,
                        lineHeight = 36.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Huzurlu bir uyku için doğru sesi seçin",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextMid
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1C1018))
                            .border(
                                1.5.dp,
                                Color(0xFF6B2040),
                                CircleShape
                            )
                            .clickable {
                                navController.navigate(
                                    Screen.Profile.route)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profil",
                            tint = Color(0xFF8A3055),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    ModeToggle(
                        isChildMode = appMode == AppMode.CHILD,
                        onToggle = { viewModel.toggleAppMode() },
                        trackActiveColor = Color(0xFF3A1228),
                        trackActiveBorder = Color(0xFF6B2040),
                        thumbActiveColor = Color(0xFF8A3055),
                        thumbIconTint = Color(0xFFF0D0DC),
                        labelColor = Color(0xFF8A3055),
                        labelInactiveColor = Color(0xFF5A3848)
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(34.dp))
            
            Text(
                text = "ŞU AN ÇALIYOR",
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp,
                color = TextLow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            NowPlayingCard(
                selectedSound = selectedSound,
                isPlaying = isPlaying,
                progress = progress,
                playingItem = playingItem,
                navController = navController,
                onPlayToggle = { viewModel.togglePlay() }
            )
            
            Spacer(modifier = Modifier.height(34.dp))
            
            Text(
                text = "RAHATLATICI SESLER",
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp,
                color = TextLow
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            SoundGrid(
                categories = soundCategories,
                selectedCategory = selectedCategory,
                onSelect = { category ->
                    viewModel.openCategory(category)
                    navController.navigate(Screen.SoundList.route)
                }
            )
            
            Spacer(modifier = Modifier.height(36.dp))

            TimerCard(
                timerMinutes = timerMinutes,
                timerRemainingSeconds = timerRemainingSeconds,
                isTimerPending = isTimerPending,
                isTimerConfirmed = isTimerConfirmed,
                isTimerRunning = isTimerRunning,
                isTimerPaused = isTimerPaused,
                onAdjust = { viewModel.adjustTimer(it) },
                onConfirm = { viewModel.confirmTimer() },
                onPause = { viewModel.pauseTimer() },
                onResume = { viewModel.resumeTimer() },
                onReset = { viewModel.resetTimer() }
            )

            Spacer(modifier = Modifier.height(26.dp))
            
            Text(
                text = "Bebeğinizin huzurlu uykusu için özenle hazırlandı ✦",
                fontSize = 12.sp,
                color = TextLow,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
    }
}
