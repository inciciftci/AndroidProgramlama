package com.example.bebiksoundsapp.data.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "sound_items")
public class SoundItemEntity {

    @PrimaryKey
    private int id;

    private String name;
    private int audioResId;
    private String duration;

    public SoundItemEntity(int id, String name, int audioResId, String duration) {
        this.id = id;
        this.name = name;
        this.audioResId = audioResId;
        this.duration = duration;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAudioResId() {
        return audioResId;
    }

    public void setAudioResId(int audioResId) {
        this.audioResId = audioResId;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
