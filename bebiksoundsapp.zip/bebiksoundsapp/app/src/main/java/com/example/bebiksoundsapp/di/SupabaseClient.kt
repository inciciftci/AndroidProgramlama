package com.example.bebiksoundsapp.di

import com.example.bebiksoundsapp.BuildConfig
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage

object SupabaseClient {
    private fun validateConfig(url: String, key: String) {
        val trimmedUrl = url.trim().removeSuffix("/")
        val invalidUrl = trimmedUrl.isBlank() ||
            trimmedUrl.contains("senin-proje-id") ||
            trimmedUrl.contains("/rest/v1")
        val invalidKey = key.isBlank() ||
            key.contains("senin-anon-key") ||
            !key.startsWith("eyJ")
        if (invalidUrl || invalidKey) {
            throw IllegalStateException(
                "Supabase ayari gecersiz. SUPABASE_URL yalnizca proje alan adi olmali (https://<project-ref>.supabase.co), SUPABASE_ANON_KEY ise API Keys altindaki anon public JWT olmali."
            )
        }
    }

    val client = createSupabaseClient(
        supabaseUrl = BuildConfig.SUPABASE_URL,
        supabaseKey = BuildConfig.SUPABASE_ANON_KEY
    ) {
        validateConfig(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_ANON_KEY)
        install(Auth)
        install(Postgrest)
        install(Storage)
    }
}
