package com.example.bebiksoundsapp.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.bebiksoundsapp.model.SoundCategory
import com.example.bebiksoundsapp.ui.Screen
import com.example.bebiksoundsapp.ui.SoundItem
import com.example.bebiksoundsapp.ui.theme.*

@Composable
fun NowPlayingCard(
    selectedSound: SoundCategory,
    isPlaying: Boolean,
    progress: Float,
    playingItem: SoundItem?,
    navController: NavController,
    onPlayToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(color = Surface1, shape = RoundedCornerShape(30.dp))
            .clickable(enabled = playingItem != null) {
                navController.navigate(Screen.Player.route)
            }
            .padding(24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Sol — emoji ikonu
        Box(
            modifier = Modifier
                .size(58.dp)
                .background(color = Surface2, shape = RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = selectedSound.emoji, fontSize = 30.sp)
        }

        Spacer(modifier = Modifier.width(18.dp))

        // Orta (weight=1f) — Column
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "ŞU AN ÇALIYOR",
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.8.sp,
                color = TextLow
            )
            Text(
                text = selectedSound.name,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextHigh
            )
            Spacer(modifier = Modifier.height(7.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(10.dp)),
                color = AccentLight,
                trackColor = Surface2,
                strokeCap = StrokeCap.Round
            )
        }

        Spacer(modifier = Modifier.width(18.dp))

        // Sağ — Play/Pause butonu
        Box(
            modifier = Modifier
                .size(52.dp)
                .background(color = Accent, shape = CircleShape)
                .clip(CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    onPlayToggle()
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (isPlaying) "⏸" else "▶",
                color = TextHigh,
                fontSize = 20.sp
            )
        }
    }
}
