package com.example.bebiksoundsapp.analysis;

import com.example.bebiksoundsapp.data.model.SleepSession;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SleepAnalyzer {

    // En iyi sesi bul
    public static String getBestCategory(
            List<SleepSession> sessions) {
        if (sessions.size() < 3)
            return null;

        Map<String, Integer> totalMinutes =
            new HashMap<>();
        Map<String, Integer> successCount =
            new HashMap<>();
        Map<String, Integer> sessionCount =
            new HashMap<>();

        for (SleepSession s : sessions) {
            if (!s.isBabySlept()) continue;
            String cat = s.getCategory();
            totalMinutes.merge(
                cat, s.getMinutesToSleep(),
                Integer::sum);
            successCount.merge(cat, 1,
                Integer::sum);
            sessionCount.merge(cat, 1,
                Integer::sum);
        }

        // En az 2 başarılı oturumu olan,
        // ortalama en kısa sürede uyutan kategori
        String bestCat = null;
        double bestAvg = Double.MAX_VALUE;

        for (String cat : successCount.keySet()) {
            if (successCount.get(cat) < 2)
                continue;
            double avg = (double)
                totalMinutes.get(cat) /
                successCount.get(cat);
            if (avg < bestAvg) {
                bestAvg = avg;
                bestCat = cat;
            }
        }
        return bestCat;
    }

    // En iyi saati bul
    public static String getBestTime(
            List<SleepSession> sessions) {
        if (sessions.size() < 3)
            return null;

        Map<String, Integer> hourSuccess =
            new HashMap<>();
        Map<String, Integer> hourTotal =
            new HashMap<>();

        for (SleepSession s : sessions) {
            // Saati "21" gibi al
            String hour = s.getTime()
                .substring(0, 2);
            hourTotal.merge(hour, 1,
                Integer::sum);
            if (s.isBabySlept()) {
                hourSuccess.merge(hour, 1,
                    Integer::sum);
            }
        }

        // En yüksek başarı oranına sahip saat
        String bestHour = null;
        double bestRate = -1;

        for (String hour : hourTotal.keySet()) {
            if (hourTotal.get(hour) < 2)
                continue;
            double rate = (double)
                hourSuccess.getOrDefault(hour, 0) /
                hourTotal.get(hour);
            if (rate > bestRate) {
                bestRate = rate;
                bestHour = hour;
            }
        }
        return bestHour != null ?
            bestHour + ":00" : null;
    }

    // Öneri metni üret
    public static String generateSuggestion(
            List<SleepSession> sessions) {
        if (sessions.size() < 5) {
            return "Öneri için daha fazla " +
                "veri gerekiyor. " +
                sessions.size() +
                "/5 oturum tamamlandı.";
        }

        String bestCat =
            getBestCategory(sessions);
        String bestTime =
            getBestTime(sessions);

        if (bestCat == null && bestTime == null) {
            return "Henüz belirgin bir " +
                "pattern bulunamadı.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Bebeğiniz için öneri:\n\n");

        if (bestCat != null) {
            sb.append("🎵 En iyi ses: ")
              .append(bestCat)
              .append("\n");
        }
        if (bestTime != null) {
            sb.append("🕐 En iyi saat: ")
              .append(bestTime)
              .append(" civarı\n");
        }

        return sb.toString();
    }
}
