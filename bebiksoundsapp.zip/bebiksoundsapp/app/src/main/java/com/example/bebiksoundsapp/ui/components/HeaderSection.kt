package com.example.bebiksoundsapp.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.bebiksoundsapp.ui.theme.TextHigh
import com.example.bebiksoundsapp.ui.theme.TextLow
import com.example.bebiksoundsapp.ui.theme.TextMid

@Composable
fun HeaderSection() {
    Column {
        Text(
            text = "UYKU MODU",
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 2.5.sp,
            color = TextLow
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Bebeğiniz için\nrahatlatıcı sesler",
            fontSize = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TextHigh,
            lineHeight = 32.sp
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Huzurlu bir uyku için doğru sesi seçin",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = TextMid
        )
    }
}
