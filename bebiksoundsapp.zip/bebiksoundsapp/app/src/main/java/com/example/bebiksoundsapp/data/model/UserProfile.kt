package com.example.bebiksoundsapp.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UserProfile(
    val id: String = "",
    val email: String = "",
    @SerialName("display_name")
    val displayName: String = "",
    val username: String = "",
    @SerialName("profile_photo_url")
    val profilePhotoUrl: String = "",
    @SerialName("created_at")
    val createdAt: String = ""
)
