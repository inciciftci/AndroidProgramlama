package com.example.bebiksoundsapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.bebiksoundsapp.data.AppDatabase
import com.example.bebiksoundsapp.data.model.SleepSession
import com.example.bebiksoundsapp.ui.Screen
import com.example.bebiksoundsapp.ui.SoundViewModel
import com.example.bebiksoundsapp.ui.AppMode
import com.example.bebiksoundsapp.ui.screens.ChildScreen
import com.example.bebiksoundsapp.ui.screens.AnalysisScreen
import com.example.bebiksoundsapp.ui.screens.LoginScreen
import com.example.bebiksoundsapp.ui.screens.MainScreen
import com.example.bebiksoundsapp.ui.screens.PlayerScreen
import com.example.bebiksoundsapp.ui.screens.ProfileScreen
import com.example.bebiksoundsapp.ui.screens.RegisterScreen
import com.example.bebiksoundsapp.ui.screens.SoundListScreen
import com.example.bebiksoundsapp.ui.screens.WelcomeScreen
import com.example.bebiksoundsapp.ui.theme.BebeSesTheme
import com.example.bebiksoundsapp.viewmodel.AuthViewModel
import java.time.LocalDate
import java.time.LocalTime

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread {
            val dao = AppDatabase.getInstance(applicationContext).sleepSessionDao()
            if (dao.getSessionCount() == 0) {
                val session = SleepSession().apply {
                    date = LocalDate.now().toString()
                    time = LocalTime.now().withNano(0).toString()
                    category = "Test"
                    songName = "Seed"
                    playDuration = 60
                    setBabySlept(false)
                    minutesToSleep = 0
                    timerSet = 10
                }
                dao.insert(session)
            }
        }.start()
        setContent {
            BebeSesTheme {
                val navController = rememberNavController()
                val authViewModel: AuthViewModel = viewModel()
                val soundViewModel: SoundViewModel = viewModel()
                val isLoggedIn by authViewModel
                    .isLoggedIn.collectAsState()

                val startDest = if (isLoggedIn)
                    Screen.Main.route
                else
                    Screen.Welcome.route

                val appMode by soundViewModel.appMode.collectAsState()
                LaunchedEffect(appMode) {
                    when (appMode) {
                        AppMode.CHILD -> {
                            if (navController.currentDestination?.route != Screen.Child.route) {
                                navController.navigate(Screen.Child.route) {
                                    launchSingleTop = true
                                    // Çocuk moduna geçerken Parent stack'i koru ama duplicate ekleme.
                                    popUpTo(Screen.Main.route) { inclusive = false }
                                }
                            }
                        }
                        AppMode.PARENT -> {
                            // Parent'a dönerken Child ve alt ekranları temizle.
                            val popped = navController.popBackStack(Screen.Main.route, false)
                            if (!popped && navController.currentDestination?.route != Screen.Main.route) {
                                navController.navigate(Screen.Main.route) {
                                    launchSingleTop = true
                                    popUpTo(0)
                                }
                            }
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = startDest
                ) {
                    composable(Screen.Welcome.route) {
                        WelcomeScreen(navController)
                    }
                    composable(Screen.Login.route) {
                        LoginScreen(navController)
                    }
                    composable(Screen.Register.route) {
                        RegisterScreen(navController)
                    }
                    composable(Screen.Main.route) {
                        MainScreen(navController, soundViewModel)
                    }
                    composable(Screen.SoundList.route) {
                        SoundListScreen(navController, soundViewModel)
                    }
                    composable(Screen.Player.route) {
                        PlayerScreen(navController, soundViewModel)
                    }
                    composable(Screen.Child.route) {
                        ChildScreen(navController, soundViewModel)
                    }
                    composable(Screen.Analysis.route) {
                        AnalysisScreen(navController, soundViewModel)
                    }
                    composable(Screen.Profile.route) {
                        ProfileScreen(navController)
                    }
                }
            }
        }
    }
}
