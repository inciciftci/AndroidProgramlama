package com.example.bebiksoundsapp

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.bebiksoundsapp.model.SoundCategory
import com.google.android.material.card.MaterialCardView

class SoundAdapter(
    private val categories: List<SoundCategory>,
    private val onSelect: (SoundCategory) -> Unit
) : RecyclerView.Adapter<SoundAdapter.SoundViewHolder>() {

    var selectedId: Int = -1
        set(value) {
            if (field == value) return
            val oldIdx = categories.indexOfFirst { it.id == field }
            val newIdx = categories.indexOfFirst { it.id == value }
            field = value
            if (oldIdx != -1) notifyItemChanged(oldIdx)
            if (newIdx != -1) notifyItemChanged(newIdx)
        }

    // Renkleri ve boyutları önbelleğe alarak performansı artırıyoruz
    private var colorSurface1: Int = 0
    private var colorSurface2: Int = 0
    private var colorAccent: Int = 0
    private var colorTextHigh: Int = 0
    private var colorTextMid: Int = 0
    private var density: Float = 0f

    inner class SoundViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardSound: MaterialCardView = itemView.findViewById(R.id.card_sound)
        val cardIconBg: MaterialCardView = itemView.findViewById(R.id.card_icon_bg)
        val tvEmoji: TextView = itemView.findViewById(R.id.tv_emoji)
        val tvName: TextView = itemView.findViewById(R.id.tv_name)
        val viewSelectedDot: View = itemView.findViewById(R.id.view_selected_dot)

        fun bind(category: SoundCategory, isSelected: Boolean) {
            tvEmoji.text = category.emoji
            tvName.text = category.name
            
            // Renk dönüşümünü optimize et
            val icBgColor = Color.argb(
                (category.iconBackground.alpha * 255).toInt(),
                (category.iconBackground.red * 255).toInt(),
                (category.iconBackground.green * 255).toInt(),
                (category.iconBackground.blue * 255).toInt()
            )
            cardIconBg.setCardBackgroundColor(icBgColor)

            if (isSelected) {
                cardSound.setCardBackgroundColor(colorSurface2)
                cardSound.strokeWidth = (2 * density).toInt()
                tvName.setTextColor(colorAccent)
                viewSelectedDot.visibility = View.VISIBLE
            } else {
                cardSound.setCardBackgroundColor(colorSurface1)
                cardSound.strokeWidth = 0
                tvName.setTextColor(colorTextMid)
                viewSelectedDot.visibility = View.INVISIBLE
            }

            cardSound.setOnClickListener { onSelect(category) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SoundViewHolder {
        val context = parent.context
        if (density == 0f) {
            colorSurface1 = ContextCompat.getColor(context, R.color.surface_1)
            colorSurface2 = ContextCompat.getColor(context, R.color.surface_2)
            colorAccent = ContextCompat.getColor(context, R.color.accent)
            colorTextMid = ContextCompat.getColor(context, R.color.text_mid)
            density = context.resources.displayMetrics.density
        }
        val view = LayoutInflater.from(context).inflate(R.layout.item_sound, parent, false)
        return SoundViewHolder(view)
    }

    override fun onBindViewHolder(holder: SoundViewHolder, position: Int) {
        val category = categories[position]
        holder.bind(category, category.id == selectedId)
    }

    override fun getItemCount() = categories.size
}
