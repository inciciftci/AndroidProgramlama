package com.example.bebiksoundsapp.ui.theme

import androidx.compose.ui.graphics.Color

val BgColor       = Color(0xFF120810)   // Ana arka plan
val Surface1      = Color(0xFF1C1018)   // Kart arka planı
val Surface2      = Color(0xFF261820)   // Hover / aktif kart
val Accent        = Color(0xFF6B2040)   // Ana vurgu (buton, border)
val AccentLight   = Color(0xFF8A3055)   // Hover, progress bar
val AccentDim     = Color(0xFF3A1228)   // Soluk ikon arka planı
val TextHigh      = Color(0xFFC8A8B4)   // Ana metin
val TextMid       = Color(0xFF8A6070)   // İkincil metin
val TextLow       = Color(0xFF5A3848)   // Hint / label metin
val AmberColor    = Color(0xFF9A6820)   // Zamanlayıcı uyarı rengi

val ChildBg1 = Color(0xFFFFF8E8)
val ChildBg2 = Color(0xFFFFF3D8)
val ChildBg3 = Color(0xFFF5FFE8)
val ChildBg4 = Color(0xFFFFFBF0)

val ChildOrange = Color(0xFFE07020)
val ChildOrangeLight = Color(0xFFFF9A40)
val ChildYellow = Color(0xFFFFD060)
val ChildYellowLight = Color(0xFFFFE8A0)
val ChildRed = Color(0xFFD03030)
val ChildRedLight = Color(0xFFFF6060)
val ChildBlue = Color(0xFF4070D0)
val ChildGreen = Color(0xFF40A040)

val ChildTextDark = Color(0xFF5A3820)
val ChildTextMid = Color(0xFFA07848)
val ChildTextAmber = Color(0xFFC4904A)

// Child mode shared palette
val ChildSurface = Color(0xFFFFFBF0)
val ChildSurfaceSoft = Color(0xFFFFF3D8)
val ChildSurfaceAccent = Color(0xFFFFE8A0)
val ChildBorder = Color(0xFFD29638)
val ChildShadow = Color(0xFFB47828)

// ModeToggle — Çocuk modu (pastel, yumuşak kontrast)
val ChildToggleTrack = Color(0xFFD6EEF8)
val ChildToggleBorder = Color(0xFFB8D9EC)
val ChildToggleThumb = Color(0xFFFFF3DD)
val ChildToggleIcon = Color(0xFF7A9EB8)
