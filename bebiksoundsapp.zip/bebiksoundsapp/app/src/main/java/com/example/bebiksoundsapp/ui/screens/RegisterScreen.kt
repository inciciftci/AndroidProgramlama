package com.example.bebiksoundsapp.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIos
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.bebiksoundsapp.ui.Screen
import com.example.bebiksoundsapp.ui.components.AuthTextField
import com.example.bebiksoundsapp.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(navController: NavController) {
    val authViewModel: AuthViewModel = viewModel()
    val isLoading by authViewModel
        .isLoading.collectAsState()
    val errorMessage by authViewModel
        .errorMessage.collectAsState()
    val isLoggedIn by authViewModel
        .isLoggedIn.collectAsState()

    var displayName by remember {
        mutableStateOf("") }
    var username by remember {
        mutableStateOf("") }
    var email by remember {
        mutableStateOf("") }
    var password by remember {
        mutableStateOf("") }
    var confirmPassword by remember {
        mutableStateOf("") }
    var photoUri by remember {
        mutableStateOf<Uri?>(null) }
    var kvkkAccepted by remember {
        mutableStateOf(false) }
    var termsAccepted by remember {
        mutableStateOf(false) }
    var passwordVisible by remember {
        mutableStateOf(false) }

    val photoPicker =
        rememberLauncherForActivityResult(
            ActivityResultContracts
                .PickVisualMedia()
        ) { uri -> photoUri = uri }

    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn) {
            navController.navigate(
                Screen.Main.route) {
                popUpTo(Screen.Welcome.route) {
                    inclusive = true
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF120810))
            .verticalScroll(rememberScrollState())
            .padding(
                horizontal = 24.dp,
                vertical = 52.dp
            ),
        verticalArrangement =
            Arrangement.spacedBy(16.dp)
    ) {
        Row(
            verticalAlignment =
                Alignment.CenterVertically,
            modifier = Modifier
                .padding(bottom = 8.dp)
        ) {
            IconButton(onClick = {
                navController.popBackStack()
            }) {
                Icon(
                    Icons.Default.ArrowBackIos,
                    contentDescription = "Geri",
                    tint = Color(0xFF8A6070),
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = "Hesap Oluştur",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFC8A8B4)
            )
        }

        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(Color(0xFF261820))
                .border(
                    2.dp,
                    Color(0xFF6B2040),
                    CircleShape
                )
                .clickable {
                    photoPicker.launch(
                        PickVisualMediaRequest(
                            ActivityResultContracts
                                .PickVisualMedia
                                .ImageOnly
                        )
                    )
                }
                .align(Alignment.CenterHorizontally),
            contentAlignment = Alignment.Center
        ) {
            if (photoUri != null) {
                AsyncImage(
                    model = photoUri,
                    contentDescription = "Profil",
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else {
                Column(
                    horizontalAlignment =
                        Alignment.CenterHorizontally
                ) {
                    Text("📷", fontSize = 24.sp)
                    Text(
                        text = "Fotoğraf ekle",
                        fontSize = 10.sp,
                        color = Color(0xFF8A6070)
                    )
                }
            }
        }

        AuthTextField(
            value = displayName,
            onValueChange = { displayName = it },
            label = "Ad Soyad",
            placeholder = "Adınızı girin"
        )

        AuthTextField(
            value = username,
            onValueChange = {
                username = it.lowercase()
                    .filter { c ->
                        c.isLetterOrDigit() ||
                        c == '_' || c == '.'
                    }
            },
            label = "Kullanıcı Adı",
            placeholder = "ornek_kullanici",
            prefix = "@"
        )

        AuthTextField(
            value = email,
            onValueChange = { email = it },
            label = "E-posta",
            placeholder = "ornek@email.com",
            keyboardType = KeyboardType.Email
        )

        AuthTextField(
            value = password,
            onValueChange = { password = it },
            label = "Şifre",
            placeholder = "En az 6 karakter",
            isPassword = true,
            passwordVisible = passwordVisible,
            onPasswordToggle = {
                passwordVisible = !passwordVisible
            }
        )

        AuthTextField(
            value = confirmPassword,
            onValueChange = {
                confirmPassword = it },
            label = "Şifre Tekrar",
            placeholder = "Şifreyi tekrar girin",
            isPassword = true,
            passwordVisible = passwordVisible,
            onPasswordToggle = {
                passwordVisible = !passwordVisible
            }
        )

        Row(
            verticalAlignment =
                Alignment.CenterVertically,
            modifier = Modifier.clickable {
                kvkkAccepted = !kvkkAccepted
            }
        ) {
            Checkbox(
                checked = kvkkAccepted,
                onCheckedChange = {
                    kvkkAccepted = it },
                colors = CheckboxDefaults.colors(
                    checkedColor = Color(0xFF6B2040),
                    uncheckedColor = Color(0xFF5A3848)
                )
            )
            Text(
                text = "KVKK Aydınlatma Metni'ni " +
                    "okudum ve onaylıyorum. " +
                    "Kişisel verilerimin " +
                    "işlenmesine izin veriyorum.",
                fontSize = 12.sp,
                color = Color(0xFF8A6070),
                lineHeight = 18.sp
            )
        }

        Row(
            verticalAlignment =
                Alignment.CenterVertically,
            modifier = Modifier.clickable {
                termsAccepted = !termsAccepted
            }
        ) {
            Checkbox(
                checked = termsAccepted,
                onCheckedChange = {
                    termsAccepted = it },
                colors = CheckboxDefaults.colors(
                    checkedColor = Color(0xFF6B2040),
                    uncheckedColor = Color(0xFF5A3848)
                )
            )
            Text(
                text = "Kullanım Koşulları'nı " +
                    "okudum ve kabul ediyorum.",
                fontSize = 12.sp,
                color = Color(0xFF8A6070)
            )
        }

        if (errorMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Color(0xFF6B2040)
                            .copy(alpha = 0.2f))
                    .padding(12.dp)
            ) {
                Text(
                    text = "⚠️ $errorMessage",
                    fontSize = 13.sp,
                    color = Color(0xFFE8A0A0)
                )
            }
        }

        Button(
            onClick = {
                authViewModel.register(
                    email = email,
                    password = password,
                    confirmPassword = confirmPassword,
                    displayName = displayName,
                    username = username,
                    photoUri = photoUri,
                    kvkkAccepted = kvkkAccepted,
                    termsAccepted = termsAccepted
                )
            },
            enabled = !isLoading,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF6B2040),
                disabledContainerColor =
                    Color(0xFF3A1228)
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    color = Color(0xFFF0D0DC),
                    modifier = Modifier.size(24.dp)
                )
            } else {
                Text(
                    text = "Hesap Oluştur",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFFF0D0DC)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement =
                Arrangement.Center
        ) {
            Text(
                text = "Zaten hesabın var mı? ",
                fontSize = 13.sp,
                color = Color(0xFF5A3848)
            )
            Text(
                text = "Giriş Yap",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF8A3055),
                modifier = Modifier.clickable {
                    navController.navigate(
                        Screen.Login.route)
                }
            )
        }
    }
}
