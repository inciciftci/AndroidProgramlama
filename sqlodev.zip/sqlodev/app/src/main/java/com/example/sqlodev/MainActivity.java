package com.example.sqlodev;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextAd, editTextSoyad, editTextYas, editTextSehir;
    private Button buttonKayit, buttonGoster, buttonSil, buttonGuncelle;
    ListView listView;
    ArrayList<Ogrenci> ogrenciListesi;
    ArrayAdapter<Ogrenci> adapter;
    String seciliAd = "";
    private veritabani vt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Bileşenlerin tanımlanması
        editTextAd = findViewById(R.id.editTextAd);
        editTextSoyad = findViewById(R.id.editTextSoyad);
        editTextYas = findViewById(R.id.editTextYas);
        editTextSehir = findViewById(R.id.editTextSehir);
        buttonKayit = findViewById(R.id.buttonKayit);
        buttonGoster = findViewById(R.id.buttonGoster);
        buttonSil = findViewById(R.id.buttonSil);
        buttonGuncelle = findViewById(R.id.buttonGuncelle);
        listView = findViewById(R.id.listViewBilgiler);

        ogrenciListesi = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ogrenciListesi);
        listView.setAdapter(adapter);

        // Veritabanı nesnesinin oluşturulması
        vt = new veritabani(this);

        // ListView tıklama olayı
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Ogrenci secilenOgrenci = ogrenciListesi.get(position);
                editTextAd.setText(secilenOgrenci.getAd());
                editTextSoyad.setText(secilenOgrenci.getSoyad());
                editTextYas.setText(secilenOgrenci.getYas());
                editTextSehir.setText(secilenOgrenci.getSehir());
                seciliAd = secilenOgrenci.getAd();
                Toast.makeText(MainActivity.this, "Seçilen: " + seciliAd, Toast.LENGTH_SHORT).show();
            }
        });

        // Buton olayları
        buttonKayit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                KayitEkle();
            }
        });

        buttonGoster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                KayitGoster();
            }
        });

        buttonSil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!seciliAd.isEmpty()) {
                    KayitSil(seciliAd);
                    Temizle();
                    KayitGoster();
                } else {
                    Toast.makeText(MainActivity.this, "Lütfen bir kayıt seçin", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonGuncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!seciliAd.isEmpty()) {
                    KayitGuncelle(seciliAd);
                    Temizle();
                    KayitGoster();
                } else {
                    Toast.makeText(MainActivity.this, "Lütfen bir kayıt seçin", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void KayitEkle() {
        try {
            SQLiteDatabase db = vt.getWritableDatabase();
            ContentValues veriler = new ContentValues();

            String ad = editTextAd.getText().toString();
            String soyad = editTextSoyad.getText().toString();
            String yasStr = editTextYas.getText().toString();
            String sehir = editTextSehir.getText().toString();

            int yas = 0;
            if (!yasStr.isEmpty()) {
                yas = Integer.parseInt(yasStr);
            }

            veriler.put("ad", ad);
            veriler.put("soyad", soyad);
            veriler.put("yas", yas);
            veriler.put("sehir", sehir);

            db.insertOrThrow("OgrenciBilgi", null, veriler);
            Log.d("Veritabanı", "Kayıt başarıyla eklendi: " + ad);
            Toast.makeText(this, "Kayıt Eklendi", Toast.LENGTH_SHORT).show();

            Temizle();

        } catch (Exception e) {
            Log.e("Veritabanı Hatası", "Kayıt eklenirken hata oluştu", e);
            Toast.makeText(this, "Hata: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void KayitGoster() {
        Cursor cursor = null;
        try {
            SQLiteDatabase db = vt.getReadableDatabase();
            cursor = db.rawQuery("SELECT * FROM OgrenciBilgi", null);
            
            ogrenciListesi.clear();

            while (cursor.moveToNext()) {
                String ad = cursor.getString(cursor.getColumnIndexOrThrow("ad"));
                String soyad = cursor.getString(cursor.getColumnIndexOrThrow("soyad"));
                String yas = cursor.getString(cursor.getColumnIndexOrThrow("yas"));
                String sehir = cursor.getString(cursor.getColumnIndexOrThrow("sehir"));

                Ogrenci ogrenci = new Ogrenci(ad, soyad, yas, sehir);
                ogrenciListesi.add(ogrenci);
            }

            adapter.notifyDataSetChanged();
            Log.d("Veritabanı", "Kayıtlar başarıyla getirildi.");

        } catch (Exception e) {
            Log.e("Veritabanı Hatası", "Kayıtlar getirilirken hata oluştu", e);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private void KayitSil(String ad) {
        try {
            SQLiteDatabase db = vt.getWritableDatabase();

            int sonuc = db.delete("OgrenciBilgi", "ad=?", new String[]{ad});

            if (sonuc > 0) {
                Log.d("Veritabanı", "Kayıt silindi: " + ad);
                Toast.makeText(this, "Kayıt Silindi", Toast.LENGTH_SHORT).show();
            } else {
                Log.d("Veritabanı", "Silinecek kayıt bulunamadı: " + ad);
                Toast.makeText(this, "Kayıt Bulunamadı", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("Veritabanı Hatası", "Kayıt silinirken hata oluştu", e);
        }
    }

    private void KayitGuncelle(String eskiAd) {
        try {
            SQLiteDatabase db = vt.getWritableDatabase();
            ContentValues veriler = new ContentValues();

            String ad = editTextAd.getText().toString();
            String soyad = editTextSoyad.getText().toString();
            String yasStr = editTextYas.getText().toString();
            String sehir = editTextSehir.getText().toString();

            int yas = 0;
            if (!yasStr.isEmpty()) {
                yas = Integer.parseInt(yasStr);
            }

            veriler.put("ad", ad);
            veriler.put("soyad", soyad);
            veriler.put("yas", yas);
            veriler.put("sehir", sehir);

            int sonuc = db.update("OgrenciBilgi", veriler, "ad=?", new String[]{eskiAd});

            if (sonuc > 0) {
                Log.d("Veritabanı", "Kayıt güncellendi: " + ad);
                Toast.makeText(this, "Kayıt Güncellendi", Toast.LENGTH_SHORT).show();
            } else {
                Log.d("Veritabanı", "Güncellenecek kayıt bulunamadı: " + ad);
                Toast.makeText(this, "Kayıt Bulunamadı", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e("Veritabanı Hatası", "Kayıt güncellenirken hata oluştu", e);
        }
    }

    private void Temizle() {
        editTextAd.setText("");
        editTextSoyad.setText("");
        editTextYas.setText("");
        editTextSehir.setText("");
        seciliAd = "";
    }
}
