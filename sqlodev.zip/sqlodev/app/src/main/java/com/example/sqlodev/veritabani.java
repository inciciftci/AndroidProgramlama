package com.example.sqlodev;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class veritabani extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Ogrenciler.db";
    private static final int DATABASE_VERSION = 2;

    public veritabani(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE OgrenciBilgi (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ad TEXT NOT NULL, " +
                "soyad TEXT NOT NULL, " +
                "yas INTEGER NOT NULL, " +
                "sehir TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS OgrenciBilgi");
        onCreate(db);
    }
}
