package com.example.hafta8;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.Set;

public class BluetoothActivity extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter;
    private ListView lvDevices;
    private ArrayList<String> pairedDevicesList;
    private ArrayAdapter<String> adapter;
    private TextView tvStatus;

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        lvDevices = findViewById(R.id.lvDevices);
        tvStatus = findViewById(R.id.tvStatus);
        Button btnBtOn = findViewById(R.id.btnBtOn);
        Button btnBtOff = findViewById(R.id.btnBtOff);
        Button btnBtPaired = findViewById(R.id.btnBtPaired);
        Button btnBack = findViewById(R.id.btnBack);

        pairedDevicesList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, pairedDevicesList);
        lvDevices.setAdapter(adapter);

        if (bluetoothAdapter == null) {
            tvStatus.setText("Durum: Bluetooth Desteklenmiyor");
            Toast.makeText(this, "Cihaz Bluetooth desteklemiyor.", Toast.LENGTH_SHORT).show();
            return;
        }

        updateStatus();

        btnBtOn.setOnClickListener(v -> {
            if (checkPermissions()) {
                enableBluetooth();
            } else {
                requestPermissions();
            }
        });

        btnBtOff.setOnClickListener(v -> {
            // Android 12+ (API 31+) için uygulamadan Bluetooth kapatmak kısıtlıdır.
            // En görünür ve güvenilir yol ayarlar panelini açmaktır.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                startActivity(intent);
            } else {
                if (checkPermissions()) {
                    disableBluetoothLegacy();
                } else {
                    requestPermissions();
                }
            }
        });

        btnBtPaired.setOnClickListener(v -> {
            if (checkPermissions()) {
                listPairedDevices();
            } else {
                requestPermissions();
            }
        });

        btnBack.setOnClickListener(v -> finish());
    }

    private void updateStatus() {
        if (bluetoothAdapter.isEnabled()) {
            tvStatus.setText("Durum: Bluetooth AÇIK");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        } else {
            tvStatus.setText("Durum: Bluetooth KAPALI");
            tvStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        }
    }

    @SuppressLint("MissingPermission")
    private void enableBluetooth() {
        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            Toast.makeText(this, "Bluetooth zaten açık.", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("MissingPermission")
    private void disableBluetoothLegacy() {
        if (bluetoothAdapter.isEnabled()) {
            bluetoothAdapter.disable();
            Toast.makeText(this, "Bluetooth kapatılıyor...", Toast.LENGTH_SHORT).show();
            updateStatus();
        } else {
            Toast.makeText(this, "Bluetooth zaten kapalı.", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("MissingPermission")
    private void listPairedDevices() {
        if (!bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "Lütfen önce Bluetooth'u açın.", Toast.LENGTH_SHORT).show();
            return;
        }
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        pairedDevicesList.clear();
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                pairedDevicesList.add(device.getName() + "\n" + device.getAddress());
            }
        } else {
            Toast.makeText(this, "Eşleşmiş cihaz bulunamadı.", Toast.LENGTH_SHORT).show();
        }
        adapter.notifyDataSetChanged();
    }

    private boolean checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
            }, PERMISSION_REQUEST_CODE);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            }, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bluetoothAdapter != null) {
            updateStatus();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BT) {
            updateStatus();
        }
    }
}