package com.example.hafta8;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class WifiActivity extends AppCompatActivity {

    private WifiManager wifiManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi);

        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        Button btnWifiSettings = findViewById(R.id.btnWifiSettings);
        Button btnBack = findViewById(R.id.btnBack);

        // Not: Android 10 (API 29) ve sonrasında uygulamalar Wi-Fi'yi doğrudan açıp kapatamaz.
        // Bu yüzden kullanıcıyı ayarlara veya panel ayarlarına yönlendirmek en sağlıklı yöntemdir.
        btnWifiSettings.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ için hızlı ayar paneli
                Intent panelIntent = new Intent(Settings.Panel.ACTION_WIFI);
                startActivity(panelIntent);
            } else {
                // Eski sürümler için Wi-Fi ayarları
                Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                startActivity(intent);
            }
        });

        btnBack.setOnClickListener(v -> finish());
    }
}